# Privacy policy

Last updated: October 2026

- [Introduction](#introduction)
- [Information we collect](#information-we-collect)
- [How we use it](#how-we-use-it)
- [Legal bases for processing (GDPR)](#legal-bases-for-processing-gdpr)
- [Sharing & subprocessors](#sharing-and-subprocessors)
- [Apple Health](#apple-health)
- [On-device storage, cookies & local storage](#on-device-storage-cookies-and-local-storage)
- [Data retention](#data-retention)
- [Data breaches](#data-breaches)
- [Your rights](#your-rights)
- [International transfers](#international-transfers)
- [Children](#children)
- [Changes to this policy](#changes-to-this-policy)
- [Contact](#contact)

## Introduction

Setkord (“Setkord”, “we”, “us”, or “our”) is a strength-training log app for iPhone, operated by Mashwork LTD, a company registered in the United Kingdom. Setkord is local-first: your training data is stored on your device and synced to our servers. This Privacy Policy explains what personal data we collect, why we collect it, and the rights you have over it.

The controller of your personal data is Mashwork LTD, a company registered in England and Wales with its registered office at 3rd Floor, 86-90 Paul Street, London, England, EC2A 4NE, United Kingdom. For any question about this policy or your data, contact us at [hello@setkord.com](mailto:hello@setkord.com).

## Information we collect

- **Account information:** your email address and, optionally, your name.
- **Authentication data:** a securely hashed password, or the account identifier from your chosen provider if you sign in with Google or with Apple. If you use Sign in with Apple and choose to hide your email, we receive only Apple’s private-relay address.
- **Training data:** the exercises, sets, weights, reps, durations, and notes you log, the routines you build and share, and the personal records calculated from that data.
- **Health & body measurements:** if you record them, your body weight and body measurements (for example chest, waist, arms). These are optional.
- **Profile & demographics:** optional details you may add - date of birth, sex, height, country, training experience level, and primary goal - used to tailor stats and, where you opt in, communications.
- **Preferences:** your chosen units, theme, text size, and contrast settings.
- **Subscription and billing status:** whether you are on a free or paid plan, and its current status. Payments are processed by Apple through the App Store (in-app purchase) - we never receive or store your card details.
- **Pseudonymous product analytics:** app usage events (for example, that a workout was finished), collected via TelemetryDeck. Each event carries a salted, hashed device identifier so we can count devices, but never your name, email address, account or training data, and we only look at the results in aggregate.

## How we use it

- To provide and operate Setkord: store and display your training data, calculate progress and personal records, and keep your preferences in sync across sessions.
- To authenticate you and keep your account secure.
- To process billing and maintain accurate subscription records, for any paid plan.
- To contact you about your account, such as password resets and important service notices.
- To understand aggregate, pseudonymous product usage and improve Setkord.
- To comply with our legal obligations, such as retaining billing records.

## Legal bases for processing (GDPR)

Where the GDPR applies to you (for example, if you are in the EU or UK), we rely on the following legal bases:

- **Contract:** processing needed to provide the service you signed up for, including your account, training data, and preferences.
- **Legitimate interests:** securing the service, preventing abuse, and understanding aggregate usage patterns.
- **Consent:** where you opt in to an optional feature, such as signing in with Google or Apple.
- **Explicit consent (special-category data):** body weight, body measurements, and workout history can be health-related data. Where such data is special category under UK or EU law, we process it on the basis of your explicit consent, which you can withdraw at any time by removing the data or deleting your account.
- **Legal obligation:** retaining billing records to meet tax and accounting requirements.

## Sharing & subprocessors

We do not sell your personal information, and we do not share it with advertisers. We share data only with service providers (“subprocessors”) who help us run Setkord, each given only the access needed to perform their function:

- **Apple** - Sign in with Apple (authentication), and subscription billing and payment processing via the App Store (in-app purchase).
- **PowerSync** - the data-sync engine that keeps your on-device data in sync with our servers; it processes your training and body-measurement data in transit.
- **Sentry** - error and crash monitoring, which may receive technical request context when something fails.
- **Resend** - delivery of transactional email, such as password resets and account notices.
- **Hetzner** - hosting of our servers and databases.
- **Google Drive** - encrypted, off-site storage of our database backups. Backups are encrypted before they leave our server, so their contents are not readable by the storage provider.
- **Cloudflare** - content delivery network, DNS, and security.
- **Google** - optional sign-in with a Google account, if you choose that method.
- **TelemetryDeck** - privacy-first, pseudonymous product analytics.

We may also disclose information where required by law, or to protect the rights, property, or safety of Setkord, our users, or others.

## Apple Health

If you enable it, Setkord writes your completed workouts to Apple Health on your device. We do not read any data from Apple Health. Data written to Apple Health is stored by Apple in your device’s Health store, under your control - you can review or revoke Setkord’s access at any time in the Health app. We never use Apple Health data for advertising or marketing, and we never sell it.

## On-device storage, cookies & local storage

Setkord is local-first: on iPhone, your workouts, routines, and body measurements are stored on your device (in an on-device database) and synced to our servers so you can use the app offline and across devices. On the web, Setkord uses a single essential session cookie to keep you signed in (via NextAuth), and stores your theme, contrast, and text-size preferences in your browser’s local storage. We do not use advertising or cross-site tracking cookies.

## Data retention

We keep your account and training data for as long as your account exists. When you delete your account, this data is removed. Billing records are retained for approximately 7 years to meet financial and legal obligations. Analytics data is pseudonymous and is not linked to your account, so we cannot find it to remove it when you delete your account.

If you shared a routine and another user imported it, their copy is independent and is not removed when you delete your account or the original.

## Data breaches

If a personal-data breach occurs that is likely to affect your rights, we will notify the relevant supervisory authority and, where required, affected users without undue delay, in line with applicable law.

## Your rights

Depending on where you live, you have the right to:

- **Access** the personal data we hold about you.
- **Correct** inaccurate or incomplete data.
- **Delete** your data - available in-app from Profile, or by emailing [hello@setkord.com](mailto:hello@setkord.com). Deletion is permanent.
- **Export** your data (data portability) - Setkord includes a built-in data export feature so you can take your training history with you.
- **Object to or restrict** certain processing.

**California residents (CCPA/CPRA):** We do not sell your personal information, and we have not sold it in the preceding twelve months. You have the right to know what personal information we collect, to request its deletion, and to not be discriminated against for exercising your rights.

To exercise any of these rights, use the relevant control in the app (Profile) or email [hello@setkord.com](mailto:hello@setkord.com). We may need to verify your identity before acting on a request.

If you are in the UK and believe we have not handled your data properly, you have the right to lodge a complaint with the Information Commissioner's Office (ICO) at ico.org.uk.

## International transfers

Setkord is operated from the United Kingdom, and our subprocessors operate in a number of countries, including the UK, the EU/EEA, and the United States. Where we transfer personal data across borders, we rely on the transfer mechanisms recognised by the relevant privacy laws (for example, the UK International Data Transfer Agreement and EU Standard Contractual Clauses), and we require our subprocessors to protect your data to a standard consistent with this policy.

## Children

Setkord is not directed to children. It is not intended for use by anyone under 13 (or under 16 in the European Economic Area and the United Kingdom), and we do not knowingly collect personal data from children. If you believe a child has provided us with personal data, contact us at [hello@setkord.com](mailto:hello@setkord.com) and we will delete it.

## Changes to this policy

We may update this policy from time to time. When we do, we will update the “Last updated” date above, and for material changes we will notify you by email or through the app.

## Contact

Questions, requests, or complaints about this policy or your data: [hello@setkord.com](mailto:hello@setkord.com). We aim to respond within a reasonable time.

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/privacy
