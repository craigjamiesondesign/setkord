[Back to blog](https://setkord.com/blog)

# How to Progressive Overload: 6 Methods and When to Use Each

2 September 2026 · Mark Stent

- strength
- progression



To progressively overload, you make training harder over time by changing one of six things: the weight, the reps, the number of sets, the range of motion, how often you train a lift, or how much you rest. Most people only ever use the first one - add weight - and then panic when it stops working. The skill is knowing which lever to pull, and in what order, so you always have a next move.

This is the practical companion to [progressive overload](https://setkord.com/blog/progressive-overload), the pillar guide. Start there for the why; this is the how.

## The six progressive overload methods

Each of these is a legitimate way to tell your body "do more than last time". They are not equal - some are cheap and repeatable, some are one-time upgrades you cannot keep spending.

|Method |Best for |How often you can spend it |
|---|---|---|
|Add weight |Strength, the default |Beginner: every session. Advanced: rarely |
|Add reps |Everything, between weight jumps |Weekly, many times over |
|Add sets |Muscle, weekly volume |Occasionally - has a ceiling |
|Improve range of motion |Form, honest reps |Once per lift, then it is the standard |
|Add frequency |Weak lifts, more practice |Rarely - a program change |
|Reduce rest |Conditioning, density |Sparingly - trades off strength |

## Method 1: Add weight

The obvious one, and the strongest signal you can send. Put more on the bar for the same reps and your body has to adapt.

Use it as your default for strength work. The catch: the stronger you get, the less often you can spend it. A beginner adds weight every session; an advanced lifter might add 5 kg to a lift across an entire block. When the jumps get too big to make cleanly, switch to reps.

## Method 2: Add reps

The most underused lever and the one that keeps you moving when weight stalls. Same weight, one more rep than last time, is real overload.

This is the heart of [double progression](https://setkord.com/blog/linear-vs-double-progression): you climb reps at a fixed weight until you hit the top of a range, then add weight and drop back to the bottom. It turns one big scary weight jump into several small, achievable rep jumps. If you take one method away from this article, take this one.

## Method 3: Add sets

More hard sets means more total work, which is the main driver of [muscle growth](https://setkord.com/blog/how-many-sets-per-week-to-build-muscle). Going from 3 working sets to 4 on a lift is a clean progression.

But it has a ceiling. You cannot keep adding sets forever - eventually you are just accumulating fatigue you cannot recover from. Use it to build weekly volume up to a sensible amount (often somewhere around 10 to 20 hard sets per muscle per week), then hold there and progress the other levers.

## Method 4: Improve range of motion and form

A deeper squat, a full lockout, a controlled row that actually touches - a harder, honest rep at the same weight is overload, and it is the one people quietly cheat to avoid.

This is a one-time upgrade per lift: once your range is honest, that becomes the standard you progress from. It also protects you, because you build strength through the full range instead of a comfortable slice of it. Fix range before you chase weight, or you are just adding load to a half rep.

## Method 5: Add frequency

Training a lift more often - squatting twice a week instead of once - gives you more practice and more weekly volume without cramming it all into one brutal session.

This is a program-level change, not a week-to-week tweak. It is powerful for a lagging lift or a technique you want to drill, but it eats recovery, so add frequency by moving volume around, not by simply doing everything twice. Reach for it when a specific lift is stuck and you can afford to reorganise the week around it.

## Method 6: Reduce rest

Do the same work in less time and you have increased density, which is a form of overload - mostly for conditioning and work capacity.

Handle this carefully. Cutting rest usually costs you strength on the next set, so it is a poor tool for maximal work where you want [long rests between heavy sets](https://setkord.com/blog/how-long-to-rest-between-sets). Use it for accessories and conditioning, not your main strength lifts.

## The order to use them

When a lift is progressing, keep it simple:


- **Add weight** while the jumps are still makeable.
- When weight stalls, **add reps** at the same weight until you top out your range.
- Top of the range reached? **Add weight** and drop back down. Repeat 2 and 3 for a long time.
- Need more stimulus for size? **Add sets** to build weekly volume, up to a sensible ceiling.
- Fix **range of motion** any time it has drifted - it is not optional.
- Stuck for good on a lift? Change **frequency** or the program itself, and read [how to break a lifting plateau](https://setkord.com/blog/how-to-break-a-lifting-plateau).

Save **reduced rest** for conditioning, not your heavy sets.

## How to apply these methods in Setkord

The reason most people only ever use "add weight" is that it is the only lever you can eyeball. Adding a rep or a set only counts if you know precisely what you did last time - and that is exactly what a tracker is for.


- **Last weight and reps pre-fill** on every set, so adding one rep or one small plate is a deliberate choice, not a guess.
- **Automatic PR detection** and an [estimated 1RM](https://setkord.com/blog/estimated-1rm-train-off-your-numbers) chart show progress even in weeks where the bar weight never changed but the reps climbed.
- **Routines** keep your set and frequency structure consistent, so when you add a set it stays added.
- **Insights (Pro)** surfaces plateau and fatigue signals, so you know which lever to reach for next.

Works offline, built for lifters, core free forever.

## FAQ

**Which progressive overload method is best?** Adding weight for strength, adding reps for staying in the game when weight stalls. Most lifters should run the two together as double progression and only reach for sets, frequency, and range as needed. There is no single best - there is a right one for where a lift is stuck.

**Do reps really count as progressive overload?** Yes. More reps at the same weight is more total work and a clear signal to adapt. It is the lever that keeps you progressing between weight jumps, and ignoring it is why so many people stall the moment the weight stops moving.

**How many methods should I use at once?** On any given lift, one at a time. Push weight, or push reps, or add a set - not all three in the same week. Changing everything at once means you cannot tell what worked, and it buries you in fatigue. One clean progression per lift.

**What if none of the methods work anymore?** Then it is not a method problem, it is a recovery or programming problem. Check food and sleep first, then back off and run the sticking point again with a deload. See [how to break a lifting plateau](https://setkord.com/blog/how-to-break-a-lifting-plateau).

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/blog/progressive-overload-methods
