[Back to blog](https://setkord.com/blog)

# RPE vs RIR: What They Mean and How to Use Them (With Conversion Table)

2 September 2026 · Mark Stent

- tracking
- progress



RPE and RIR are two ways of recording the same thing: how hard a set was. RIR (Reps in Reserve) counts how many reps you had left before failure - 2 RIR means you could have done two more. RPE (Rate of Perceived Exertion), on the modern lifting scale, is just 10 minus your reps in reserve - an RPE of 8 is 2 reps in reserve. They are two dials showing the same number, and once you see that, choosing between them is easy.

## What RIR means

Reps in Reserve is the more literal of the two. You finish a set and ask: how many more reps could I honestly have done with good form? That answer is your RIR.


- **0 RIR** - you hit failure, no more reps in the tank.
- **2 RIR** - you stopped with two good reps left.
- **4 RIR** - fairly easy, plenty left.

It is concrete and hard to fudge, which is why a lot of lifters find it the easier of the two to learn.

## What RPE means

Rate of Perceived Exertion rates the difficulty of a set on a scale. In everyday cardio it runs 6 to 20 (the old Borg scale), but for lifting almost everyone uses the modern 1-10 scale, where the top of the scale is defined by reps left in reserve.


- **RPE 10** - maximal, nothing left.
- **RPE 8** - two reps left.
- **RPE 6** - four or more reps left, comfortable.

Because the lifting RPE scale is anchored to reps in reserve, it carries exactly the same information as RIR - just counted from the other end.

## RPE to RIR conversion table

On the modern lifting scale, the relationship is simply **RPE = 10 - RIR**:

|RPE |Reps in Reserve (RIR) |What the set felt like |
|---|---|---|
|10 |0 |Maximal - couldn't do another rep |
|9.5 |0-1 |Maybe one more, maybe not |
|9 |1 |One clean rep left |
|8 |2 |Two reps left, bar still moving well |
|7 |3 |Three left, comfortably fast |
|6 |4+ |Easy, four or more left |
|5 or below |5+ |Warm-up territory |

Keep this table in your head and RPE and RIR become interchangeable.

## Which should you use?

For most people, **RIR is easier to learn and RPE is easier to program with** - and since they convert directly, you can log in whichever feels natural and think in the other.


- **New to effort tracking?** Use RIR. "How many reps did I leave?" is a more concrete question than "rate this from 1 to 10", and beginners judge it more accurately.
- **Following a program that prescribes effort?** It probably speaks RPE (e.g. "work up to a top set at RPE 8"), so log RPE to match it.
- **Just want the signal, not the precision?** A simple 1-5 hardness scale is plenty. You don't need decimal-point accuracy to know whether to add weight next week.

The honest caveat: everyone, especially beginners, tends to underrate effort - what feels like 2 RIR is often 0. Your accuracy improves the more sets you take genuinely close to failure, because that is how you calibrate what the last rep actually feels like.

## Why log effort at all?

Because weight and reps alone don't tell you what to do next.

Three sets of 8 at 100 kg that all left 3 reps in reserve is a green light to add weight. The same three sets that all hit failure at rep 8 means you are already at your limit there - repeat it, don't jump. Effort is the field that turns your log from a record into a decision.

It also protects your program. If every session is grinding at RPE 10, you are digging a recovery hole no amount of "more volume" will fix. If everything is floating at RPE 6, you are leaving progress on the table. The number tells you which.

This is the piece that makes the rest of your tracking work - see [how to track your workouts](https://setkord.com/blog/how-to-track-workouts) for where effort fits alongside weight, reps and [volume](https://setkord.com/blog/how-to-track-training-volume).

## How Setkord tracks this for you

Effort is powerful but only if logging it is frictionless, so Setkord keeps it optional and simple:


- **Optional 1-5 effort logging** on any set - tap it when you want the extra signal, ignore it when you don't. No decimals to agonise over between sets.
- **Last weight and reps pre-fill**, so you're deciding "add or repeat?" against a real number, with your effort note right there to inform it.
- **Automatic PR detection and [estimated 1RM](https://setkord.com/blog/estimated-1rm-train-off-your-numbers) charts** turn a run of hard sets into a visible strength trend.
- **Volume stats** count only your hard working sets, so effort and volume line up.
- **Fully offline, free forever core**, built for lifters who want the signal without the busywork.

## FAQ

**Is RPE the same as RIR?** On the modern 1-10 lifting scale, yes - they carry the same information. RPE equals 10 minus your reps in reserve, so RPE 8 is 2 RIR. RIR counts up from failure; RPE counts down to it.

**Should a beginner use RPE or RIR?** RIR. Asking "how many reps could I still have done?" is more concrete than rating effort on a scale, and beginners judge it more accurately. Expect to underrate effort at first - it gets better as you take more sets close to failure.

**What RPE should most working sets be?** For general strength and size, most working sets sit around RPE 7 to 9 (1 to 3 reps in reserve). That's hard enough to drive progress without every set being a maximal grind that wrecks recovery.

**Do I have to log effort on every set?** No. Logging weight and reps is enough to apply progressive overload. Effort is an extra signal that helps you decide whether to add load or repeat - useful, but optional. Setkord keeps it a single optional tap.

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/blog/rpe-vs-rir
