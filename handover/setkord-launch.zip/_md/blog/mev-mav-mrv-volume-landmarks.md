[Back to blog](https://setkord.com/blog)

# MEV, MAV, MRV: The Volume Landmarks That Make Programming Simple

2 September 2026 · Mark Stent

- training
- volume



MEV, MAV, and MRV are three landmarks that describe how much volume a muscle needs and can handle: the minimum to grow, the range where you grow best, and the ceiling where more sets stop paying off. Put simply - MEV is the least volume that produces growth, MAV is the sweet spot above it, and MRV is the most you can recover from. Learn where you sit between them and volume programming stops being a guess.

## What the three landmarks mean

These come from Renaissance Periodization's framework, and they are the most useful mental model for volume there is:


- **MEV - Minimum Effective Volume.** The fewest hard sets per week that still cause the muscle to grow. Below this you maintain, you do not build.
- **MAV - Maximum Adaptive Volume.** The range above MEV where you get the most growth for the volume you put in. This is where you want to spend most of your training.
- **MRV - Maximum Recoverable Volume.** The most volume you can recover from and still adapt. Train above this and you accumulate fatigue faster than you can grow.

There is also **MV - Maintenance Volume**, the small amount needed just to hold what you have. Useful during a deload or a busy stretch when growth is not the goal.

## Rough numbers to anchor them

The exact figures are individual and change with your training age, sleep, and stress. But you need somewhere to start, so here are sensible ballpark figures in hard sets per muscle per week:

|Landmark |Rough range (sets/week) |What it is for |
|---|---|---|
|MV (maintenance) |4 - 6 |Holding muscle during a deload or busy period |
|MEV (minimum to grow) |8 - 10 |The floor for actual growth |
|MAV (grow best) |12 - 18 |Where you spend most of your training |
|MRV (ceiling) |18 - 22+ |The recoverable maximum - highly individual |

Treat these as starting points, not laws. Your MRV for a small muscle like biceps is different from your MRV for legs, and both drift over time.

## How to use them to program

The landmarks turn volume into a plan you can actually run across a training block:


- **Start a block near MEV.** Begin low - around 8 to 10 sets. Starting low leaves room to add, which is the entire point.
- **Add a set or two per muscle each week**, climbing through your MAV. This is the productive middle of a block where most growth happens.
- **Push toward MRV**, where sets stop feeling productive and recovery gets ragged. That is your signal.
- **Deload back down to MV**, let fatigue clear, then start the next block a little higher than the last.

This up-and-down is why cycling volume beats holding one number forever: you spend most of your time in the productive range and periodically reset the fatigue that would otherwise cap you.

## How to find your own numbers

The tables are a starting point. Your real landmarks are found by paying attention, not by copying a chart:


- **MEV shows itself** when you are growing on surprisingly few sets. If a body part grows on 8, do not add 6 more for no reason.
- **MRV shows itself** as [the signs of too much volume](https://setkord.com/blog/signs-of-too-much-training-volume) - stalled lifts, soreness that never clears, dropping performance, poor sleep. When those pile up, you have found your ceiling.
- **The gap between them is your working range.** Live in it, and cycle within it.

Every one of these landmarks only makes sense if you are counting real sets - so honest counting comes first. Make sure you know [what counts as a working set](https://setkord.com/blog/what-counts-as-a-working-set) before you trust the numbers.

## Where this fits with the rest of volume

Landmarks are the map; the day-to-day is choosing your weekly sets and progressing them. For the practical version, see [how many sets per muscle group per week](https://setkord.com/blog/how-many-sets-per-muscle-group) and the [pillar guide to training volume for muscle growth](https://setkord.com/blog/training-volume-for-muscle-growth). And remember that adding sets is only one form of progression - [progressive overload](https://setkord.com/blog/progressive-overload) through heavier loads and more reps carries just as much weight.

## How to find your landmarks in Setkord

MEV, MAV, and MRV are personal, and the only way to find them is to track volume against results over time. That is exactly the data Setkord captures:


- **Weekly sets per muscle** are counted automatically, so you always know which landmark your current volume sits near.
- **Insights (Pro)** charts volume trends over weeks, so you can see the point where more sets stopped producing progress - your MRV, in your data.
- **Muscle-balance stats** show where one body part is stuck near MEV while another is pushed past MRV.
- It **works fully offline** and pre-fills your last numbers, so tracking never gets in the way of training.

The landmarks are individual. Setkord gives you the data to find yours instead of guessing from a table.

## FAQ

**What do MEV, MAV, and MRV stand for?** Minimum Effective Volume, Maximum Adaptive Volume, and Maximum Recoverable Volume. They describe the least volume that grows a muscle, the range where it grows best, and the most it can recover from.

**Are the MEV and MRV numbers the same for everyone?** No. They are individual and shift with your training age, recovery, sleep, and stress. The published ranges are starting points; your real numbers come from tracking your own results.

**How do I know when I have hit my MRV?** Your performance stops improving or drops, soreness lingers, sleep and motivation dip, and lifts stall. When several of those show up together, you have reached your recoverable ceiling and it is time to deload.

**Should I always train at my MAV?** Not constantly. The productive approach is to start a block near MEV, climb through MAV toward MRV, then deload to maintenance before starting again. Cycling volume beats parking at one number.

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/blog/mev-mav-mrv-volume-landmarks
