[Back to blog](https://setkord.com/blog)

# How to Warm Up for a Heavy Lift - Without Frying Your Working Sets

30 August 2026 · Mark Stent

- strength
- training
- technique



Warming up is the part of the session everyone agrees matters and almost nobody does the same way twice. Some people do a single light set and jump straight to their working weight, then wonder why the first heavy set feels awful. Others ramp with eight or nine sets and arrive at their top set already tired, having spent their best reps on the warm-up.

Both mistakes come from the same place: not knowing what a warm-up is actually for. Get that straight and the right number of sets falls out on its own.

## What a warm-up is actually for

A good warm-up does two jobs, and only two.

The first is to raise performance on the lift that follows. Warming up increases muscle temperature, blood flow, and nervous-system readiness, and a systematic review with meta-analysis found that a proper warm-up improved performance in the large majority of the studies examined [1]. Ramping into a lift also rehearses the exact movement pattern under progressively heavier load, so your groove is dialled in before the weight gets serious.

The second is to reduce injury risk. The evidence here is softer than the internet claims, but the best available reviews point toward warming up lowering injury risk rather than raising it [2].

Notice what is not on that list: burning calories, or "feeling the muscle". A warm-up is preparation for the working sets, not a workout of its own.

_Image: logging a set in the workout screen_



## General first, then specific

Split the warm-up into two stages and it gets simple.

**General warm-up.** Five to ten minutes of easy movement to raise your core temperature and get blood moving: a few minutes on a bike or rower, then some dynamic mobility for the joints you are about to load. Keep static stretching out of this part. Holding long static stretches immediately before lifting can transiently reduce force and power output, so save the long holds for after training [3].

**Specific warm-up.** This is the ramp: a handful of sets of the actual exercise, starting light and climbing toward your working weight while the reps come down. This is where the real preparation happens, and it is the part people get wrong in both directions.

## The ramp: heavier weight, fewer reps

The principle is to add load while cutting reps, so each warm-up set prepares you for the next without accumulating fatigue. You are greasing the pattern and waking up the nervous system, not chasing a pump.

A reliable template for a heavy compound, expressed as a percentage of your working weight:

|Warm-up set |Load (% of working weight) |Reps |
|---|---|---|
|1 |Empty bar / ~40% |5-8 |
|2 |~60% |4-5 |
|3 |~75% |2-3 |
|4 |~90% |1 |
|Working sets |100% |your target |

The single at ~90% is the key that most people skip. A crisp near-working-weight single primes you for the top set without costing you meaningful reps, so the first working set no longer feels like a shock.

Two adjustments keep it sensible. The heavier your working weight, the more ramp sets you need to bridge the gap; a 60kg bench needs fewer steps than a 160kg one. And keep the reps low as you approach the top, because high-rep sets at high percentages are where warm-ups quietly steal your working sets.

## How many is too many

If your top set feels weaker than it should, look at your warm-up before you blame your program. Too many warm-up sets, or too many reps in them, adds fatigue with no upside and eats into the quality of the sets that actually drive progress.

The fix is not to warm up less, it is to warm up smarter: fewer, cleaner ramp sets with low reps near the top, so you arrive at your working weight prepared but fresh. Isolation and smaller-muscle work needs almost no ramp at all, often a single feeler set is enough.

## Where tracking comes in

The maths of a ramp is fiddly. Working out 40, 60, 75, and 90 percent of your working weight, then rounding each to a load you can actually build from the plates or dumbbells in front of you, is exactly the sort of arithmetic that gets skipped mid-session.

This is why Setkord includes a warm-up calculator. Give it your working weight and it generates the ramp for you, rounding every set to a genuinely loadable weight for the bar or dumbbell, and inserts those sets above your working sets already flagged as warm-ups. Because they are marked as warm-ups, they stay out of your volume, personal records, and strength trends, so preparing properly never pollutes the numbers you care about.

You can edit the percentages and reps per set, or add and remove rungs, so the ramp matches how you actually like to work up.

## Wrapping up

Warm up with a purpose: a few minutes to raise your temperature, then a short ramp of the lift itself, heavier each set with the reps coming down, finishing with a single near your working weight. Skip the long static stretches until after, keep the ramp reps low near the top, and stop before the warm-up becomes the workout. Do that and your first working set feels like your best one, not your worst.

Build your ramp in seconds and keep your stats clean, with [Setkord](https://setkord.com/).

## References


- Fradkin AJ, Zazryn TR, Smoliga JM. Effects of Warming-up on Physical Performance: A Systematic Review With Meta-analysis. Journal of Strength and Conditioning Research. 2010;24(1):140-148. [Link](https://pubmed.ncbi.nlm.nih.gov/19996770/)
- Fradkin AJ, Gabbe BJ, Cameron PA. Does warming up prevent injury in sport? The evidence from randomised controlled trials. Journal of Science and Medicine in Sport. 2006;9(3):214-220. [Link](https://pubmed.ncbi.nlm.nih.gov/16679062/)
- Simic L, Sarabon N, Markovic G. Does pre-exercise static stretching inhibit maximal muscular performance? A meta-analytical review. Scandinavian Journal of Medicine & Science in Sports. 2013;23(2):131-148. [Link](https://pubmed.ncbi.nlm.nih.gov/22316148/)
- Behm DG, Chaouachi A. A review of the acute effects of static and dynamic stretching on performance. European Journal of Applied Physiology. 2011;111(11):2633-2651. [Link](https://pubmed.ncbi.nlm.nih.gov/21373870/)

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/blog/how-to-warm-up-for-a-heavy-lift
