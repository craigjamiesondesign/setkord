[Back to blog](https://setkord.com/blog)

# Linear vs Double Progression: Which Should You Use?

2 September 2026 · Mark Stent

- strength
- progression



Linear progression means adding weight to the bar every session at a fixed rep target. Double progression means adding reps first at a fixed weight, then adding weight once you hit the top of a rep range. Linear is faster and simpler but burns out quickly; double progression is slower but keeps working for years. Beginners should run linear until it dies, then switch to double progression - that switch is one of the most important calls you will make as a lifter.

Both are just ways of applying [progressive overload](https://setkord.com/blog/progressive-overload). The question is which schedule fits where you are.

## What is linear progression?

You pick a rep target - say 5 reps - and add a fixed amount of weight every session you hit it.


- Session 1: 60 kg x 5
- Session 2: 62.5 kg x 5
- Session 3: 65 kg x 5

Hit your reps, weight goes up next time. Simple, brutally effective, and it works right up until it doesn't. Programs like [5x5](https://setkord.com/blog/5x5-workout) are built on it.

The strength of linear progression is also its weakness: it demands a win every single session. That is fine when you are new and adapting fast. Once you are stronger, no one recovers enough to add weight every session forever, and the whole thing grinds to a halt.

## What is double progression?

You fix a weight and a rep range - say 3 sets of 8 to 12 - and climb the reps before you touch the weight.


- Week 1: 40 kg for 8, 8, 8
- Week 2: 40 kg for 10, 9, 8
- Week 3: 40 kg for 12, 11, 10
- Week 4: 40 kg for 12, 12, 12 - top of the range hit on every set
- Week 5: 42.5 kg for 8, 8, 8 - add weight, drop back to the bottom, climb again

The reps are the small, achievable wins between the bigger, harder weight jumps. Instead of demanding a heavier bar every session, you only add weight once you have earned it across the full range on every set. That is why it keeps working long after linear progression is dead.

## Linear vs double progression at a glance

| |Linear progression |Double progression |
|---|---|---|
|What you add |Weight, every session |Reps first, then weight |
|Rep target |Fixed (e.g. 5) |A range (e.g. 8 to 12) |
|Best for |Beginners, main barbell lifts |Intermediates, accessories, hypertrophy |
|Progress speed |Fast, then stops |Slower, but lasts |
|Fails when |You cannot add weight every session |You stop tracking reps closely |
|Recovery demand |High - a PR every session |Moderate - spread across weeks |

## When to switch from linear to double

Run linear progression for as long as it works. For a beginner that is usually several months - do not quit it early just because a fancier method exists. Linear is faster while it lasts, and nothing beats free strength.

Switch to double progression when you stall on linear even after a deload. The clearest signal: you fail to hit your reps for two or three sessions in a row, you back off about 10% and climb again, and you stall at the same place a second time. That is linear progression telling you it is done. Do not keep grinding it - move to reps-first.

You do not have to switch everything at once. Main barbell lifts often stay linear longest; smaller accessory lifts move to double progression early because tiny weight jumps on a curl or lateral raise are impractical anyway.

## Which should you use?


- **Brand new or returning after a long break:** linear. Take the fast, free strength while it lasts.
- **Been lifting seriously for several months, main lifts stalling:** double progression on the stalled lifts.
- **Accessory and isolation work:** double progression, always. Rep ranges suit them and the weight jumps are too coarse for pure linear.
- **Chasing size more than a big single:** double progression in the 8 to 15 range, focused on total quality reps and weekly volume.

There is no permanent winner. Most lifters use linear early, drift to double progression lift by lift, and end up running double progression on almost everything. If double progression eventually stalls too, that is a cue for [breaking a plateau](https://setkord.com/blog/how-to-break-a-lifting-plateau) with a proper deload or a periodised block.

## How to run either in Setkord

Both methods are just bookkeeping problems dressed up as training. Linear needs last session's weight; double progression needs last session's weight and every rep on every set. Miss the numbers and neither method works.


- **Last weight and reps pre-fill** per set, so you can see instantly whether you are chasing a heavier bar (linear) or one more rep (double progression).
- **Automatic PR detection** and an [estimated 1RM](https://setkord.com/blog/estimated-1rm-train-off-your-numbers) chart give you progress even in the weeks where only reps moved.
- Save each lift's scheme as a **routine** so the rep target or range stays consistent.
- **Insights (Pro)** flags the stall, so you know when it is time to switch methods rather than grind the same one.

Fully offline, built for lifters, core free forever.

## FAQ

**Is double progression better than linear progression?** Not better, just later. Linear is faster while you are a beginner because you can add weight every session. Once you cannot, double progression keeps you moving for years. Use linear until it stalls, then switch - most lifters need both across their training life.

**What rep range should I use for double progression?** Match it to the goal. Roughly 3 to 6 for strength-leaning work, 8 to 12 for a balance of size and strength, and 12 to 20 for smaller isolation lifts. Whatever you pick, add weight only when you hit the top of the range on every set.

**Can I use both at the same time?** Yes, and most people do without naming it. Keep your main barbell lifts on linear progression while they still climb, and run accessories on double progression. As the main lifts stall, move them to double progression one at a time.

**How do I know linear progression has stalled for good?** When you fail your reps, deload about 10%, climb back, and stall at the same spot a second time. One stall is a bad week; a repeated stall through the same weight after a deload means linear is done and it is time for double progression or a periodised approach.

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/blog/linear-vs-double-progression
