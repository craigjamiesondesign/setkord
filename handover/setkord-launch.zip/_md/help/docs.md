[Help centre](https://setkord.com/help)

# Documentation

Guides for getting the most out of Setkord.

- [How Setkord worksA walkthrough of logging sets, rest timers, routines, supersets, and progress tracking in Setkord.](https://setkord.com/help/docs/getting-started)
- [Frequently asked questionsAnswers to common questions about cost, platforms, privacy, data export, and deleting your account.](https://setkord.com/help/docs/faq)

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/help/docs
