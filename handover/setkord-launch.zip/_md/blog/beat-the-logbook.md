[Back to blog](https://setkord.com/blog)

# Beat the Logbook: How the Greatest Athletes Track Their Training

26 August 2026 · Mark Stent

- training
- progressive overload

In 2019, Dorian Yates published his old training notebooks. Scans of the actual handwritten pages, 1985 to 1990, over a hundred of them: date, exercise, weight, reps. An entry from 1 March 1985 has him at 230 lb bodyweight, squatting 405 for seven, then 425 for four. Seven years later he won the first of six Mr. Olympia titles.

You have had that same information in your hands and lost it. Last Thursday's incline press, the weight on the second working set, whether it was eight reps or nine. Gone by Sunday. The athletes below never lost it, and several of them say the record is what made the training work.

## Dorian Yates: he read the log before he trained

Yates kept journals from his first competition onward, and he reviewed them before every session. He walked into Temple Gym already knowing the weight and the rep count he had to beat that day.

That matters more with his style of training than most. Heavy Duty means very few working sets, sometimes one per exercise, so if you pick the wrong load you've wasted the exercise and there's no second set to fix it. Kyle Hunt, writing about Yates' method, sets the standard: "You won't always beat the logbook, but the intent should always be there."

Yates wrote down more than numbers. Date, exercise, weight, reps, and how the set felt. An eight that moved fast and an eight where the last rep took four seconds and your partner had fingers under the bar are not the same eight, and only one of them means add weight next week.

_Image: track workout_



## Mike Mentzer: the log only works if it's honest

Yates took the framework from Mike Mentzer's Heavy Duty, and Mentzer built the system on record keeping. Log the load, the reps, and a line of context like sleep and stress. Add weight or reps next time you repeat the session. If the numbers keep climbing, recovery is fine; if they stall, rest longer or cut sets.

That diagnosis only works if the page is accurate. Mentzer's position, still spelled out on his official site, is that a logbook has value only as an honest accounting of performance. No rounding 92.5 up to 95, no writing 10 when the tenth was a forced rep. Inflate the log and you'll program off the inflated version, turn up expecting a weight you never actually lifted, and blame your pre-workout.

## Frank Zane: forty years of diaries

Three-time Mr. Olympia Frank Zane kept diaries across a forty year training career. In 1997 he published them as Mind, Body, Spirit: The Personal Training Diaries, with over 180 workouts recorded between the ages of 14 and 60, arranged in order of difficulty. The book went out of print and used copies started listing around $100.

His advice to lifters starts before the first session: "Before you start going to the gym, write down specific goals." Then take a notebook and rule it into squares, so every number has a box waiting for it. He tracked food the same way, for the same reason. If you can see how you trained and what you ate, you can line both up against what your body actually did.

## Ed Coan: working out versus training

Ed Coan is widely considered the greatest powerlifter who ever lived, with an all-time total of 2,463 lb at 110 kg in 1998. Ask him where to start and he says record every single set, rep and weight of every exercise.

He uses it to separate two things that look identical from the gym floor. Working out is turning up and doing some sets. Training is aimed at a specific number on a specific date, which means it has to be measured the whole way there. Coan wrote the plan first, then wrote down what actually happened against it, so he knew every week whether the plan was still working.

## Jay Cutler: out-organise everyone else

Four-time Mr. Olympia Jay Cutler won on volume and organisation rather than raw strength, and his weight logbook sat alongside the fasted cardio and the weekly bodywork as a habit he didn't skip. Thirty-plus sets in one leg session is a lot of noise. Without a record you can't tell which of those sets is doing anything, and you'll keep all of them forever just in case.

## Arnold: one more rep than what?

Arnold Schwarzenegger's training advice keeps returning to progression and to changing exercises before they go stale. "Within a basic framework, I was constantly changing my exercises," he said of his Olympia years. Both halves of that need a record. You can't tell an exercise has stopped producing unless you know what it produced two months ago, and you can't bring it back in sensibly if you've forgotten the numbers you left it on.

In his newsletter he now describes the whole thing as follow-through: "one more rep next week, one more rep the week after that." That only means something if you know what last week was.

## Eliud Kipchoge: the notebook is ammunition

Kipchoge, the first man to run a marathon under two hours, writes down every run. The time, the pace, the location, even which shoes he wore. His camp in Kaptagat repeats roughly the same week for four months before a race, so small changes are the only signal there is, and the notebook is where they show up.

He doesn't keep it mainly for analysis. "When the race is hurting, I think of my great workouts and training," he says. It's the same job the log does when you're sitting on a bench at rep four of a heavy set, wondering whether you have the last two in you. The page says you did this a week ago at the same weight.

## Michael Phelps: handwritten and kept

Bob Bowman handwrote Michael Phelps' workouts and kept them. At a coaching convention he showed the sessions he'd written for Phelps 7, 14, 30 and 60 days out from each of the 2004, 2008, 2012 and 2016 Olympics, along with the detail that Phelps averaged 80,000 yards a week during the Michigan years.

He still uses the archive. When training goes badly, Bowman goes back to the sessions where his swimmers were successful and shows them the page. A photo of Phelps in the gym at ASU, years after Beijing, has a paper training log sitting in the corner of the frame.

_Image: log works easily_



## Why it works

Progressive overload is the mechanism behind nearly all strength and size gain, and it runs on a reference number. "A bit more than last time" is not a number. Your memory of last Tuesday's third set is worse than you think, particularly at rep eight when you're mostly concentrating on not dropping it.

A log also makes you honest. Written down, the session you cut short after four exercises is visibly a session you cut short after four exercises. Four weeks of 80 kg for 8 on incline press is a stall you can spot on a Tuesday instead of working it out in June when the mirror stops changing.

And it banks confidence. Kipchoge reaches for the notebook in his head at 35 km. Bowman shows swimmers the set they nailed in February. On the day you feel weak and can't be bothered, the log tells you that you hit 100 for 5 last Monday, which is usually enough to get the bar loaded.

The research is on general populations rather than Olympia contenders, but it points the same way. A 2009 meta-regression by Susan Michie and colleagues in Health Psychology pooled 69 physical activity evaluations covering more than 18,000 people. Self-monitoring came out strongest in combination with other self-regulation techniques such as goal setting and feedback on performance, which describes a training log attached to a program.

## What to actually record

Between them, these athletes converge on a short list.


- **Exercise, weight, reps, sets.** If you record nothing else, record this.
- **How the set felt.** Reps left in the tank, or a one-word note like "grinder". It's what tells you next week whether to add load or repeat.
- **Context.** Mentzer wanted sleep and stress on the page. A bad session on four hours' sleep means something different from a bad session on nine.
- **Bodyweight.** Zane and Yates both tracked it next to the lifts. Yates' March 1985 entry opens with it.
- **What you'll do next time.** Coan planned first, then recorded against the plan.

Then read it back. The habit that made Yates' notebooks worth publishing was opening the last entry before the first working set, every session, for years on end.

## Start with tonight's session

You don't need forty years of diaries. You need to know what you lifted last Monday while you're standing over the bar tonight, and to write down tonight's numbers before you leave the gym.

That's what [Setkord](https://setkord.com/) does: last session's numbers pre-filled when you open the exercise, a rest timer that starts itself, PRs and estimated 1RMs worked out from your history so you're not doing arithmetic between sets. It's free on iPhone, available now on the App Store. If you'd rather stay analogue, a notebook and a pen will do the job.

### Sources


- Dorian Yates Training Journal, Generation Iron: [https://generationiron.com/dorian-yates-training-journal/](https://generationiron.com/dorian-yates-training-journal/)
- Dorian Yates' journal entries and lifts, The Barbell: [https://thebarbell.com/dorian-yates-workout/](https://thebarbell.com/dorian-yates-workout/)
- The Dorian Yates Workout and Diet Program, Hunt Fitness: [https://kylehuntfitness.com/the-dorian-yates-workout-and-diet-program/](https://kylehuntfitness.com/the-dorian-yates-workout-and-diet-program/)
- Mike Mentzer official site, on logbooks and training frequency: [https://mikementzer.org/how-often-should-you-train/](https://mikementzer.org/how-often-should-you-train/)
- Frank Zane, Mind, Body, Spirit: The Personal Training Diaries; and Zane on goal setting, Sportskeeda: [https://www.sportskeeda.com/health-and-fitness/everyone-needs-concrete-objective-frank-zane-s-motivation-tips-bodybuilders](https://www.sportskeeda.com/health-and-fitness/everyone-needs-concrete-objective-frank-zane-s-motivation-tips-bodybuilders)
- Ed Coan on recording every set, HashiMashi: [https://hashimashi.com/ed-coan-deadlift-program/](https://hashimashi.com/ed-coan-deadlift-program/)
- Jay Cutler's training habits, Wellversed: [https://wellversed.in/blogs/articles/the-cutler-curriculum-6-high-performance-bodybuilding-habits-of-a-4x-mr-olympia](https://wellversed.in/blogs/articles/the-cutler-curriculum-6-high-performance-bodybuilding-habits-of-a-4x-mr-olympia)
- Arnold Schwarzenegger's training principles, Bodybuilding.com: [https://shop.bodybuilding.com/blogs/training/arnold-schwarzeneggers-8-best-training-principles](https://shop.bodybuilding.com/blogs/training/arnold-schwarzeneggers-8-best-training-principles)
- Eliud Kipchoge's training logs, Outside/Run: [https://run.outsideonline.com/training/training-plans/marathon/eliud-kipchoge-marathon-workout-training-principles/](https://run.outsideonline.com/training/training-plans/marathon/eliud-kipchoge-marathon-workout-training-principles/)
- Bob Bowman on Phelps' pre-Olympic workouts, SwimSwam: [https://swimswam.com/bowman-shares-pre-olympic-michael-phelps-workouts-asca-convention/](https://swimswam.com/bowman-shares-pre-olympic-michael-phelps-workouts-asca-convention/)
- Michie S, Abraham C, Whittington C, McAteer J, Gupta S. "Effective techniques in healthy eating and physical activity interventions: a meta-regression." Health Psychology 2009;28(6):690-701.

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/blog/beat-the-logbook
