# Blog

Training notes, product updates, and the thinking behind Setkord.

No posts match “”.

- [

2 September 2026

### The 5x5 Workout: A Complete Guide to Sets, Progression, and Who It's For

What a 5x5 workout actually is, the exact A/B split and lifts, how the add-weight-every-session progression works, the main versions (StrongLifts, Madcow, Bill Starr), and who should - and shouldn't - run it.](https://setkord.com/blog/5x5-workout)
- [

2 September 2026

### The Best Free Workout Tracker: What to Look For (and Honest Picks)

What makes a workout tracker genuinely free, the traps to avoid, and honest picks - including Setkord's free core with unlimited workouts, automatic PRs and free import.](https://setkord.com/blog/best-free-workout-tracker)
- [

2 September 2026

### The Best Offline Workout App: Why Local-First Beats Cached

Why an offline workout app matters in a real gym, the difference between local-first and merely cached, and why Setkord's local-first design never loses a set.](https://setkord.com/blog/best-offline-workout-app)
- [

2 September 2026

### The Best Workout App for Lifting: Built for Lifters, Not Everyone

What serious lifters actually need from a workout app - fast logging, automatic PRs, estimated 1RM, routines and volume - and why Setkord is built strength-first.](https://setkord.com/blog/best-workout-app-for-lifting)
- [

2 September 2026

### The Best Workout Tracking Apps in 2026 (An Honest Roundup)

An honest, no-hype look at the best workout tracking apps for lifters - Hevy, Strong, Boostcamp and Setkord - what each one is good at, who it suits, and how to pick.](https://setkord.com/blog/best-workout-tracking-apps)
- [

2 September 2026

### Deload Week: What It Is, When to Take One, and How to Do It Right

A deload week is a planned easy week that clears accumulated fatigue so you come back stronger. Here is when to take one, exactly how much to pull back, and the two ways to do it.](https://setkord.com/blog/deload-week)
- [

2 September 2026

### DOMS and Muscle Soreness: Is Being Sore Good or Bad?

Muscle soreness (DOMS) is a normal response to training, not a measure of how good the session was. Here is what causes it, whether it means growth, and when soreness is a problem.](https://setkord.com/blog/doms-muscle-soreness)
- [

2 September 2026

### Full Body Workout Routine: The Complete Guide and Weekly Plan

What a full body workout routine is, the exact three-day weekly layout, which lifts to run each session, and why full body is the best split for two to three days a week. A complete guide for lifters.](https://setkord.com/blog/full-body-workout-routine)
- [

2 September 2026

### Hevy Alternatives: The Best Options for Lifters in 2026

The best Hevy alternatives compared fairly - Strong, Boostcamp and Setkord - what each is good at, who it suits, and why Setkord fits offline, strength-first lifters (with free import from Hevy).](https://setkord.com/blog/hevy-alternatives)
- [

2 September 2026

### How Many Days a Week Should You Train? A Straight Answer for Lifters

How many days a week you should train to build muscle and strength - what 2, 3, 4, 5, and 6 days each give you, and how to match your training days to the right split. A no-fluff guide for lifters.](https://setkord.com/blog/how-many-days-a-week-to-train)
- [

2 September 2026

### How Many Sets Per Muscle Group Per Week? A Practical Set Chart

Most muscles grow well on 10 to 20 hard sets per week, split across two sessions. Here is a set-per-muscle chart, how to divide it across the week, and how to adjust for lagging body parts.](https://setkord.com/blog/how-many-sets-per-muscle-group)
- [

2 September 2026

### How to Break a Lifting Plateau: A Practical Fix-It Guide

Stuck at the same weight for weeks? Here is why lifting plateaus happen and the exact order to fix them - deload, check recovery, change the progression lever, and add variation - so you start moving again.](https://setkord.com/blog/how-to-break-a-lifting-plateau)
- [

2 September 2026

### How to Build a Workout Routine: A Complete Guide for Lifters

How to build a workout routine that actually works - pick a training split, choose the right exercises, set sets and reps, and progress week to week. A complete, no-fluff guide for lifters.](https://setkord.com/blog/how-to-build-a-workout-routine)
- [

2 September 2026

### How to Track Lifting Progress (Beyond Just Adding Weight)

How to track lifting progress properly - estimated 1RM, volume, rep PRs and bodyweight - so you can see strength climbing even when the bar weight isn't moving.](https://setkord.com/blog/how-to-track-lifting-progress)
- [

2 September 2026

### How to Track Training Volume (Sets, Reps and Tonnage Explained)

How to track training volume the right way - hard sets per muscle per week, plus tonnage when you need it - with the exact numbers to aim for and how to log them.](https://setkord.com/blog/how-to-track-training-volume)
- [

2 September 2026

### How to Track Your Workouts: The Complete Guide for Lifters

A complete, practical guide to tracking workouts - what to record on every set, how to log weight, reps and effort, and how to turn that record into progress you can actually see.](https://setkord.com/blog/how-to-track-workouts)
- [

2 September 2026

### Linear vs Double Progression: Which Should You Use?

Linear progression adds weight every session; double progression adds reps first, then weight. Here is exactly how each works, when to switch, and a worked example of both so you can pick the right one for where you are.](https://setkord.com/blog/linear-vs-double-progression)
- [

2 September 2026

### MEV, MAV, MRV: The Volume Landmarks That Make Programming Simple

MEV, MAV, and MRV are the three volume landmarks that tell you the minimum to grow, the range where you grow best, and the point where more sets stop working. Here is what each means and how to use them.](https://setkord.com/blog/mev-mav-mrv-volume-landmarks)
- [

2 September 2026

### Muscle Recovery for Lifters: The Complete Guide to Recovering Between Sessions

What muscle recovery actually means for lifters, how long muscles take to recover, and the four levers that matter most - sleep, food, rest between sessions, and deloads - so you grow instead of just grinding.](https://setkord.com/blog/muscle-recovery-for-lifters)
- [

2 September 2026

### How to Progressive Overload: 6 Methods and When to Use Each

The six real ways to progressively overload - weight, reps, sets, range, frequency, and rest - with a clear order for when to use each, so you always have a next move when a lift stalls.](https://setkord.com/blog/progressive-overload-methods)
- [

2 September 2026

### Progressive Overload: The Complete Guide to Getting Stronger on Purpose

What progressive overload is, why it is the one rule behind every result in the gym, and the concrete ways to apply it - more weight, more reps, more sets, better form - with a simple table you can follow every week.](https://setkord.com/blog/progressive-overload)
- [

2 September 2026

### Push Pull Legs Split (PPL): The Complete Guide and Weekly Plan

What the push pull legs split is, the exact weekly layout for 3 and 6 days, which muscles hit on each day, and who PPL is actually for. A complete, usable PPL guide for lifters.](https://setkord.com/blog/push-pull-legs)
- [

2 September 2026

### RPE vs RIR: What They Mean and How to Use Them (With Conversion Table)

RPE vs RIR explained simply, with a conversion table, when to use each, and how to log effort so you know whether to add weight or repeat next session.](https://setkord.com/blog/rpe-vs-rir)
- [

2 September 2026

### Setkord vs Hevy: A Fair Head-to-Head for Lifters

Setkord vs Hevy compared side by side - platforms, Apple Watch, offline logging, free plans, Pro, social features, data import and accessibility, with every Hevy claim sourced from Hevy's own pages.](https://setkord.com/blog/setkord-vs-hevy)
- [

2 September 2026

### Setkord vs Strong: A Fair Head-to-Head for Lifters

Setkord vs Strong compared side by side - platforms, Apple Watch, offline logging, free tiers, Pro plans, data import and accessibility, with every Strong claim sourced from Strong's own pages.](https://setkord.com/blog/setkord-vs-strong)
- [

2 September 2026

### 8 Signs of Too Much Training Volume (and How to Fix It)

Stalled lifts, soreness that never clears, wrecked sleep and dread before training are the classic signs of too much volume. Here is how to spot overreaching early and dial it back before it costs you.](https://setkord.com/blog/signs-of-too-much-training-volume)
- [

2 September 2026

### Sleep and Muscle Growth: Why Rest Is the Lever Most Lifters Ignore

Sleep is the single biggest recovery lever for building muscle - it is where most repair and hormonal recovery happen. Here is how much you need, why it matters, and how to fix bad nights.](https://setkord.com/blog/sleep-and-muscle-growth)
- [

2 September 2026

### Strong App Alternatives: The Best Options for Lifters in 2026

The best Strong app alternatives for strength-first lifters, including Hevy, Boostcamp and Setkord, with an honest look at offline support, free import and what each does well.](https://setkord.com/blog/strong-app-alternatives)
- [

2 September 2026

### Training Volume for Muscle Growth: The Complete Guide to Sets, Reps, and Weekly Load

Training volume is the biggest driver of muscle growth after progressive overload. Here is what volume actually means, how many hard sets per muscle per week you need, and how to add it without wrecking recovery.](https://setkord.com/blog/training-volume-for-muscle-growth)
- [

2 September 2026

### Upper Lower Split: The Complete Guide and Weekly Plan

What the upper lower split is, the exact four-day weekly layout, which muscles hit on each day, and why it is the best-fit split for four days a week. A complete, usable guide for lifters.](https://setkord.com/blog/upper-lower-split)
- [

2 September 2026

### What Counts as a Working Set? How to Tell Real Volume From Junk Volume

A working set is a hard set taken close to failure with full range of motion - the only kind that counts toward muscle growth. Here is how to separate real volume from junk volume, warm-ups, and half-reps.](https://setkord.com/blog/what-counts-as-a-working-set)
- [

30 August 2026

### Estimated 1RM: Train Off Your Numbers Without Ever Testing a True Max

You don't need to grind a true one-rep max to know how strong you are. Here's how the estimated-1RM formulas work, how accurate they actually are, and how to program off an estimate instead of risking a bad single.](https://setkord.com/blog/estimated-1rm-train-off-your-numbers)
- [

30 August 2026

### How to Warm Up for a Heavy Lift - Without Frying Your Working Sets

Too few warm-up sets and your top set feels like a car crash. Too many and you've spent your best reps warming up. Here's what the research says about warming up for strength, and a simple ramp you can reuse on every lift.](https://setkord.com/blog/how-to-warm-up-for-a-heavy-lift)
- [

26 August 2026

### Beat the Logbook: How the Greatest Athletes Track Their Training

Dorian Yates published his training journals. Frank Zane kept diaries for forty years. Eliud Kipchoge writes down every run. Here's what they recorded, and what to steal for your next session.](https://setkord.com/blog/beat-the-logbook)
- [

26 August 2026

### How Long Should You Rest Between Sets? A Research-Backed Cheat Sheet

The old advice was short rests for size, long rests for strength. The research says otherwise. Here's what the studies actually found, and how long to rest for your goal.](https://setkord.com/blog/how-long-to-rest-between-sets)
- [

26 August 2026

### How Many Sets Per Week to Build Muscle? What the Research Says

The honest, number-based answer to how much training volume builds muscle - what the studies actually found, how many sets per muscle per week to aim for, and what counts.](https://setkord.com/blog/how-many-sets-per-week-to-build-muscle)

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/blog
