[Back to blog](https://setkord.com/blog)

# What Counts as a Working Set? How to Tell Real Volume From Junk Volume

2 September 2026 · Mark Stent

- training
- volume



A working set is a genuinely hard set - a challenging load, taken through a full range of motion, and stopped within a few reps of failure. It is the only kind of set that counts toward the volume that builds muscle. Warm-ups, easy back-off sets, and sloppy half-reps are not working sets, and counting them is why a lot of high-volume programs quietly do nothing.

## What makes a set a working set

Three things have to be true for a set to count:


- **The load is challenging.** Roughly 30% of your one-rep max or heavier. Below that, you can grind out reps without ever producing enough tension to matter.
- **The range of motion is full.** Full stretch to full contraction. Cutting the range cuts most of the stimulus with it.
- **It ends close to failure.** Within about 0 to 4 reps of the point where you could not do another clean rep. This is the part people fudge most.

Miss any one of those and the set is doing far less than the number in your logbook suggests.

## Working set vs junk volume

Junk volume is any set that costs you recovery but does not add growth. It looks like training and counts like training in a naive tally, but the muscle gets almost nothing from it.

|Counts as a working set |Junk volume |
|---|---|---|
|Hard load, close to failure |Easy load, many reps left in the tank |
|Full range of motion |Cut-short, bouncy, half reps |
|Stopped within ~4 reps of failure |Stopped 6+ reps out with no intent |
|Big muscle doing the work |Momentum and cheating doing the work |

The problem with junk volume is not just that it is wasted. It still uses recovery, so it crowds out the hard sets that would have grown you. Ten focused working sets beat twenty half-committed ones, every time.

## Do warm-up sets count?

No. Warm-up sets exist to prepare the muscle and groove the movement, not to stimulate growth, so they do not count toward your weekly volume. This matters when you tally volume: if you count three warm-up sets and two real ones as "five sets", your number is more than double the truth.

A good rule: only sets at or near your working weight, taken with real intent, go in the count. Everything you did to get the bar warm is preparation, not volume. If you want to warm up well without inflating your set count, read [how to warm up for a heavy lift](https://setkord.com/blog/how-to-warm-up-for-a-heavy-lift).

## How close to failure is close enough?

For most lifters, most sets should land **1 to 4 reps short of failure** - what coaches call reps in reserve, or RIR. That range is close enough to drive growth without the deep fatigue that comes from grinding every set to a dead stop.


- **0 RIR (true failure)** - use it occasionally, mostly on isolation work where the safety risk is low. Every set to failure is expensive to recover from.
- **1 - 3 RIR** - the sweet spot for most working sets.
- **4+ RIR** - fine for warm-ups and technique work, but stop counting it as volume. There is too much left in the tank.

The honest test: if you finished a set and truly could have done five or six more clean reps, it was not a working set.

## Why this changes your whole volume count

If you have been counting warm-ups and easy sets, your real working volume is probably far lower than you think - which is often why a "high-volume" program is not producing much. Recount using only true working sets and two things usually happen: the number drops, and it starts to line up with your actual results.

This is the foundation under every volume decision. Once you count sets honestly, the rest of the framework works: [how many sets per muscle group per week](https://setkord.com/blog/how-many-sets-per-muscle-group), the [MEV, MAV, and MRV landmarks](https://setkord.com/blog/mev-mav-mrv-volume-landmarks), and the [pillar guide to training volume for muscle growth](https://setkord.com/blog/training-volume-for-muscle-growth).

## How to track working sets in Setkord

The hard part of counting working sets is being honest and consistent about it, set after set, week after week. Setkord makes that automatic:


- **Warm-up sets can be marked as warm-ups** and are excluded from your volume totals, so your weekly count only reflects real working sets.
- Every working set is **tagged to a muscle group**, so your true volume per muscle adds up on its own.
- Your **last weight and reps pre-fill**, so it is obvious whether today's set is a genuine progression or a repeat of an easy one.
- **Automatic PR detection** and [estimated 1RM](https://setkord.com/blog/estimated-1rm-train-off-your-numbers) charts tell you whether your working sets are actually getting harder over time, or just accumulating.

Count the sets that count, ignore the ones that do not.

## FAQ

**Do warm-up sets count as volume?** No. Warm-ups prepare the muscle but do not provide a growth stimulus, so they should not be counted toward your weekly working sets. In Setkord you can mark them as warm-ups so they are excluded automatically.

**How many reps in reserve should a working set have?** Aim for 1 to 4 reps in reserve on most sets. That is close enough to failure to drive growth without the heavy fatigue of grinding every set to a dead stop.

**Is a set to failure better than a set with reps in reserve?** Not usually. Occasional sets to failure are fine, especially on isolation work, but training every set to failure costs far more recovery for little extra growth. Most working sets should stop a few reps short.

**Can light weights build muscle?** Yes, if the set is still a real working set - full range of motion and taken close to failure. Very light loads with lots of reps left in the tank are junk volume and build little.

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/blog/what-counts-as-a-working-set
