[Back to blog](https://setkord.com/blog)

# DOMS and Muscle Soreness: Is Being Sore Good or Bad?

2 September 2026 · Mark Stent

- recovery
- training



Muscle soreness after training - properly called DOMS, delayed onset muscle soreness - is normal and mostly harmless, but it is a poor measure of how good a session was. Being sore does not mean you grew, and not being sore does not mean you wasted your time. It mainly tells you that you did something your muscles were not yet used to.

So soreness is neither good nor bad on its own. What matters is whether it clears in a couple of days or sticks around and starts eating into your training.

## What is DOMS?

DOMS is the muscle soreness that shows up **12 to 48 hours after training** and usually peaks around a day or two later, before fading over the next few days. It comes from the mechanical stress of training - particularly the lengthening (eccentric) part of a lift, and especially from movements or loads your muscles are not adapted to yet.

The old story that DOMS is caused by lactic acid is wrong. Lactate clears within an hour or two of training. DOMS is a delayed response to muscle stress and the low-grade inflammation of repair, which is why it arrives the next day rather than during the workout.

## Does soreness mean muscle growth?

No - not reliably. This is the biggest misconception in the gym.

Soreness tracks **novelty** more than growth. You get sore from a new exercise, a big jump in volume, or a lot of eccentric work. Do that same session repeatedly and the soreness fades within a few weeks even as you keep building muscle - this is the "repeated bout effect", your body adapting so the same stimulus no longer damages it as much.

So you can:


- Grow well with barely any soreness (a familiar, well-progressed program)
- Be extremely sore and grow little (a random brutal session you never repeat)

Chasing soreness leads people to constantly change their program for the wrong reason. Consistency and progressive overload build muscle. Soreness is just a side effect that comes and goes. If you want the real driver, it is [training volume](https://setkord.com/blog/training-volume-for-muscle-growth) applied consistently.

## Should you train a sore muscle?

It depends on how sore, and what kind.

|Soreness level |What it feels like |What to do |
|---|---|---|
|Mild |Slight ache, eases once you warm up |Train as normal - it often improves with movement |
|Moderate |Clearly stiff, tender to press, limits range a bit |Train, but consider lighter loads or lower volume that day |
|Severe |Painful to move, swollen, still there after 3 - 4 days |Give it more time; do not load it hard |
|Sharp / joint pain |Localised, stabbing, or in a joint not a muscle |Stop - this is not DOMS, treat it as a possible injury |

Mild soreness usually eases once you [warm up properly](https://setkord.com/blog/how-to-warm-up-for-a-heavy-lift) and get blood into the muscle - light movement is often the best thing for it. The line to watch is soreness that never clears between sessions. That is not a badge of a good workout; it is a sign your [recovery](https://setkord.com/blog/muscle-recovery-for-lifters) is not keeping up with your training.

## How to reduce soreness

You cannot eliminate DOMS, but you can keep it manageable:


- **Progress gradually.** Big sudden jumps in weight or volume are the main cause. Add load in small steps.
- **Warm up before heavy work** so you are not going from cold to loaded in one step.
- **Sleep and eat enough.** Recovery is where soreness resolves - [sleep and muscle growth](https://setkord.com/blog/sleep-and-muscle-growth) covers why this matters most.
- **Keep moving.** Light activity on a sore day usually helps more than complete rest.
- **Do not over-rely on ice, painkillers, or hard stretching.** They may dull the feeling but do little for the actual recovery, and blunting inflammation aggressively may even blunt some of the adaptation.

## When soreness is telling you something

Occasional soreness after a hard or new session is normal. Persistent, widespread soreness across weeks is a signal, usually one of these:


- You increased volume or intensity too fast
- You are not sleeping or eating enough to recover
- You are overdue a [deload week](https://setkord.com/blog/deload-week)

If soreness is chronic and your strength is also going backwards, that is under-recovery, not toughness. Back off before it becomes an injury or a stall - [how to break a lifting plateau](https://setkord.com/blog/how-to-break-a-lifting-plateau) covers what to do if you have already hit the wall.

One warning worth stating plainly: severe soreness with dark urine, extreme swelling, and pain far beyond normal - especially after a very hard unfamiliar session - can be a medical issue, not ordinary DOMS. That is a doctor visit, not a foam roller.

## How Setkord helps you read your soreness

Soreness is a feeling; your training is data. Setkord helps you tell whether soreness reflects real progress or just too much too fast:


- **Training history and volume trends** show whether a sore week followed a genuine jump in work - so you can tell a good hard session from an overreach.
- **Muscle-balance and fatigue signals** (Insights, Pro) flag when a muscle group is getting hammered week after week, the pattern behind soreness that never clears.
- **Strength trends** reveal whether you are progressing or stalling underneath the soreness.
- **Fully offline logging**, a **built-in rest timer**, and the ability to **back-date a session** keep your record accurate - and the core is **free forever**, built for lifters.

## FAQ

**Is being sore after a workout a good sign?** It is a normal sign that you challenged the muscle, but not a measure of how effective the session was. You can grow with little soreness and be very sore without growing. Judge your training by progression over time, not by how sore you feel.

**How long should DOMS last?** Usually 1 to 3 days, peaking around 24 to 48 hours after training. Soreness that regularly lasts longer than 3 to 4 days, or never clears between sessions, means you are doing too much or recovering too little.

**Should I work out if I am still sore?** Mild to moderate soreness is fine to train through, and often eases once you warm up. Severe soreness, or any sharp or joint pain, means give it more time - that is not ordinary DOMS.

**Why am I not sore anymore even though I train hard?** Your muscles have adapted to your program, so the same work no longer damages them as much. This is normal and does not mean you have stopped progressing - keep applying progressive overload and track your numbers, not your soreness.

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/blog/doms-muscle-soreness
