[Back to blog](https://setkord.com/blog)

# Full Body Workout Routine: The Complete Guide and Weekly Plan

2 September 2026 · Mark Stent

- programs
- training



A full body workout routine trains every major muscle group in a single session, run two to three times a week with a rest day between each. Each workout has a lower-body push, a lower-body pull or hinge, an upper-body push, an upper-body pull, and a little accessory work - so the whole body gets hit every time you train. It is the best split for anyone training two or three days a week, because it keeps every muscle at high frequency even on a light schedule.

## What is a full body workout routine?

Instead of splitting the body across the week, you cover it all in one session. Every full-body workout should contain:


- **A squat or knee-dominant lift** - squat, leg press, lunge.
- **A hinge or hamstring lift** - deadlift, Romanian deadlift, hip thrust.
- **An upper-body push** - bench press, overhead press, dip.
- **An upper-body pull** - row, pull-up, lat pulldown.
- **Accessories** - a couple of smaller movements for arms, shoulders, or calves.

That is five or six exercises that together touch every major muscle. Train three times a week and each muscle gets **three exposures a week** - frequency a body-part split can only dream of.

## The full body weekly plan

A three-day full-body week, with the main lift rotated each session so nothing gets stale:

|Day |Main lower |Main upper push |Main upper pull |Accessories |
|---|---|---|
|Mon |Squat |Bench press |Barbell row |Curls, calves |
|Wed |Deadlift |Overhead press |Pull-up |Triceps, abs |
|Fri |Front squat |Incline bench |Lat pulldown |Lateral raise, calves |

Rotating the main lifts (squat / deadlift / front squat, bench / press / incline) means each muscle is trained three times a week but never the exact same way three times, which keeps recovery manageable and hits it from more than one angle.

## Full body on two days a week

If two days is all you have, full body is still the right answer - it is the only split that keeps every muscle at a usable frequency on so few sessions:

|Day |Focus |
|---|---|---|
|Mon |Full body A (squat-led) |
|Thu |Full body B (deadlift-led) |

Two hard full-body sessions a week will build real strength and size for a beginner or anyone maintaining. A body-part split on two days would leave most muscles trained once every week or worse - which is why frequency, not fancy exercise selection, is the point here.

## Sets, reps, and volume

Because you hit each muscle multiple times a week, you only need a **few hard sets per muscle per session** - often two to four - to reach a productive weekly total. Three sessions of three sets lands each muscle around **9 to 12 hard sets per week**, comfortably inside the range covered in [training volume for muscle growth](https://setkord.com/blog/training-volume-for-muscle-growth) and [how many sets per week to build muscle](https://setkord.com/blog/how-many-sets-per-week-to-build-muscle).

Reps are ordinary: 5 to 8 on the heavy compounds, 8 to 15 on accessories. The frequency does the heavy lifting, not exotic rep schemes.

## Who the full body routine is for (and who it isn't)

**Full body is a great fit if you:** train two or three days a week, are a beginner or returning lifter, have an unpredictable schedule (missing one day costs less when every day hits everything), or just want maximum results from minimum sessions.

**Look elsewhere if you:** can train four or more days and want more volume per muscle - an [upper/lower split](https://setkord.com/blog/upper-lower-split) or [push pull legs](https://setkord.com/blog/push-pull-legs) will use those extra days better - or you specifically want a heavy barbell-strength focus, where a [5x5](https://setkord.com/blog/5x5-workout) (itself a full-body style plan) fits the bill.

Still deciding? Start from [how to build a workout routine](https://setkord.com/blog/how-to-build-a-workout-routine) and let your available days pick the split - two or three points straight here.

## How to run full body in Setkord

Five or six exercises with rotating main lifts is easy to lose track of. Setkord is built for exactly this:


- **Save Full Body A and B as routines** (or start from the built-in program library) and open the right one in a tap.
- **Your last weight and reps pre-fill** on every set, so [progressive overload](https://setkord.com/blog/progressive-overload) is obvious, not guesswork.
- **Personal records and your [estimated 1RM](https://setkord.com/blog/estimated-1rm-train-off-your-numbers) are tracked automatically.**
- It **works fully offline** and the core is **free forever**.

You run the plan; Setkord keeps the score.

## FAQ

**Is a full body workout good for building muscle?** Yes. Training each muscle two or three times a week is excellent for growth, and full body is the simplest way to get that frequency on few sessions. As long as your weekly hard sets are in range and you progress, it builds size and strength well.

**How many days a week should I do a full body routine?** Two or three, with a rest day between sessions. Full body is specifically the best-fit split for that range. If you can train four or more days, a split that hits each muscle across separate days usually uses the extra time better.

**Can I do a full body workout every day?** No. Every muscle needs recovery, so back-to-back full-body sessions dig a fatigue hole. Leave at least a day between them - three sessions a week is the practical ceiling for this style.

**Full body or a split - which is better for beginners?** Full body, in most cases. Beginners progress fastest on high frequency and simple sessions, and full body delivers both. Move to an [upper/lower](https://setkord.com/blog/upper-lower-split) or [PPL](https://setkord.com/blog/push-pull-legs) split later, when you can train more days and want more volume.

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/blog/full-body-workout-routine
