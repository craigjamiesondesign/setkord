[Back to documentation](https://setkord.com/help/docs)

# How Setkord works

Setkord is built around one idea: logging a set should take seconds, not menus. Here is how the app fits together, from your first tap to your first personal record.

## Logging your first set

Open an exercise and you land straight on the logger - no extra taps to find it. Enter the weight and reps with the steppers or the keypad, then hit **Log**. Your last numbers for that exercise are pre-filled automatically, so most sets are just a tap or two of adjustment before you log them.

Every set you log is saved instantly and feeds your history, so the next time you do that exercise, Setkord already knows where you left off.

## The rest timer

As soon as you log a set, Setkord starts a rest timer automatically. No stopwatch, no separate app. You can adjust the default rest time in Settings, and override it per exercise when a lift needs longer between sets. If you leave the app or lock your phone, the timer keeps running and sends you a notification when rest is over, so you can keep your eyes off your screen between sets.

## Routines and templates

Rather than rebuilding your session from scratch every time, build a routine once: pick your exercises, set your target sets and reps, and save it. Templates let you keep a library of routines (push day, leg day, your current programme) and start any of them with a single tap on Train.

Routines stay flexible in the moment. Swap an exercise, add an extra set, or skip something entirely, and it only affects that session, not the saved template.

## Supersets

Pair exercises together as a superset and Setkord tracks the rest and history for the pair as a unit, so alternating between two movements stays just as fast as logging a straight set.

## Collapsing exercises

Long sessions can mean a long list of exercises on screen. Collapse any exercise you have finished to fold away its logged sets and keep your current exercise front and centre. Nothing is lost - expand it again any time to review or edit what you logged.

## Progress, estimated 1RM, and PRs

Every set you log feeds your Progress charts automatically. Track volume and top sets over time per exercise, and see your estimated one-rep max update as your working weights climb. When you beat a previous best, Setkord celebrates it on the spot with a PR moment, so you know the instant it happens, not days later when you happen to check your history.

## Works offline

Setkord logs work with or without a signal. Log sets in a gym with no reception and everything syncs the next time you are back online. Your workout never has to wait on a connection.

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/help/docs/getting-started
