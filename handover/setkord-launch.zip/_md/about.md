# Why I built Setkord

I have tracked every workout I have done for over thirty years, first in notebooks, then in spreadsheets, Apple Notes, and most of the tracking apps you can name. Some good, some bad, none of them gave me what I wanted.

I competed as a bodybuilder and held the WABBA South African heavyweight title, and I have an obsession with fitness. I am also a data scientist with a master's in data science and mathematics.

That combination left me with thirty years of training data and nothing good to do with it. On top of that, my goals have changed. As you age you need to be a continual student, and I believe the only way to learn is to track and make sense of your progress.

Setkord is what I built for myself: an opinionated training log built around progression and consistency. I use it every single session. It's simple but effective.

I hope you get as much value from it as I do, and if you have any suggestions on how I can improve it, my doors are always open.

Mark

## Who makes Setkord

Setkord is built and operated by Mashwork LTD, a company registered in the United Kingdom. Every message that comes through the [contact form](https://setkord.com/contact) reaches me directly.

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/about
