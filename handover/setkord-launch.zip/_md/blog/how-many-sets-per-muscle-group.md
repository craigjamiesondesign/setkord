[Back to blog](https://setkord.com/blog)

# How Many Sets Per Muscle Group Per Week? A Practical Set Chart

2 September 2026 · Mark Stent

- training
- volume



Most muscle groups grow well on 10 to 20 hard sets per week, and the sweet spot for the average lifter sits around 12 to 16. Split that across two sessions rather than one, count only real working sets, and adjust up for muscles you want to bring up and down for ones that are already ahead. That is the whole answer - the rest is applying it to your own body.

## A set-per-muscle-group chart

Bigger, harder-to-recover muscles and lagging body parts sit at the higher end; smaller muscles that also get worked indirectly sit lower. Here is a sensible weekly range in hard sets:

|Muscle group |Sets per week |Notes |
|---|---|---|
|Chest |12 - 18 |Split across two sessions |
|Back |14 - 20 |Gets hit from both rows and pulls |
|Quads |12 - 18 |High recovery cost - build up slowly |
|Hamstrings |10 - 16 |Often undertrained relative to quads |
|Shoulders (delts) |12 - 20 |Side delts usually need the most direct work |
|Biceps |8 - 14 |Already worked by all your pulling |
|Triceps |8 - 14 |Already worked by all your pressing |
|Glutes |10 - 16 |Overlaps heavily with squats and hinges |
|Calves |10 - 16 |Stubborn - most people undertrain them |

Start each muscle near the bottom of its range and add from there. These are ranges to grow into over a block, not targets to hit in week one.

## Why you should split it across the week

Doing all your weekly sets for a muscle in one session is worse than splitting them, for two reasons. First, set quality falls off a cliff late in a long session - your tenth chest set is nowhere near as productive as your third. Second, hitting a muscle twice a week means two clean growth stimuli instead of one long, fatigued grind.

The practical rule: **train each muscle at least twice a week**, splitting its weekly sets roughly in half. So 16 sets of back becomes two sessions of about 8, not one session of 16. Same volume, more usable stimulus. This is why a well-built [workout routine](https://setkord.com/blog/how-to-build-a-workout-routine) beats a random collection of sessions.

## Count working sets, not total sets

The chart only works if you are counting the right sets. A weekly total made of warm-ups and easy back-off sets is a fantasy number. Only count sets that were genuinely hard - a challenging load, full range of motion, stopped within a few reps of failure. Everything else is [junk volume](https://setkord.com/blog/what-counts-as-a-working-set) and does not belong in the tally.

Recount an average training week honestly and most people find their real numbers are lower than the chart - which is usually why a body part is not moving.

## Direct vs indirect volume

Biceps and triceps sit low on the chart for a reason: they already do a lot of work during your back and chest training. Every row hits your biceps; every press hits your triceps. If you add 14 direct sets of biceps on top of a full back routine, the real total is far higher, and you will likely run into [the signs of too much volume](https://setkord.com/blog/signs-of-too-much-training-volume).

Count indirect work as roughly half a direct set when you tally. A muscle that gets hammered indirectly needs less direct volume, not more.

## Adjust for lagging muscles

The chart is a starting distribution, not a fixed one. If a body part is behind, the fix is usually to give it more sets and take a few from somewhere that is already ahead - keeping your total recoverable.


- **Bring a lagging muscle toward the top of its range** and train it more frequently.
- **Trim an over-developed one to the bottom of its range** to free up recovery.
- **Do not just add to the total** - your overall recoverable volume has a ceiling ([your MRV](https://setkord.com/blog/mev-mav-mrv-volume-landmarks)). Rebalancing beats piling on.

For the reasoning behind all of this, see the [pillar guide to training volume for muscle growth](https://setkord.com/blog/training-volume-for-muscle-growth) and [how many sets per week to build muscle](https://setkord.com/blog/how-many-sets-per-week-to-build-muscle). And remember volume is only half the job - the load has to climb too, which is [progressive overload](https://setkord.com/blog/progressive-overload).

## How to count sets per muscle in Setkord

Adding up hard sets per muscle across a full training week, session by session, is exactly the kind of bookkeeping people give up on. Setkord does it for you:


- Every working set is **tagged to a muscle group**, so your weekly count per muscle builds automatically - no chart to fill in.
- **Muscle-balance stats** show which body parts are over the top of their range and which are stuck at the bottom, so rebalancing is obvious.
- **Warm-ups are excluded** from the count, so your totals reflect real working sets.
- **Insights (Pro)** tracks each muscle's volume over time, so you can see whether that lagging body part is actually getting more work or you just meant to give it more.

Set your ranges, train, and let the count tell you the truth.

## FAQ

**How many sets per muscle group per week is best for growth?** Most muscles grow well on 10 to 20 hard sets per week, with around 12 to 16 being the sweet spot for the average lifter. Start low and add sets only when progress stalls.

**Should I train a muscle once or twice a week?** At least twice. Splitting your weekly sets across two sessions keeps set quality higher and gives the muscle two growth stimuli instead of one long, fatigued session.

**Do biceps and triceps need as many sets as back and chest?** Usually fewer directly, because they already get worked hard during all your pulling and pressing. Count that indirect work when you tally, and add direct sets on top of it, not in place of it.

**What if one muscle is lagging behind?** Move it toward the top of its set range and train it more often, and trim a muscle that is already ahead to keep your total recoverable. Rebalancing beats simply adding more to everything.

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/blog/how-many-sets-per-muscle-group
