[Home](https://setkord.com/)

# Sign in

Your Setkord account lives on setkord.com.

Not available in this preview

Signing in and account pages need the live Setkord service, so they don't work in this design preview. You can still [visit the help centre](https://setkord.com/help).

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/login
