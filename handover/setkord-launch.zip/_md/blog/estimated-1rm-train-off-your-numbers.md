[Back to blog](https://setkord.com/blog)

# Estimated 1RM: Train Off Your Numbers Without Ever Testing a True Max

30 August 2026 · Mark Stent

- strength
- training
- progress



Testing a true one-rep max is the least practical way to find out how strong you are. It needs a spotter, a good day, a warm-up that does not fry you, and the skill to grind a maximal single without your technique falling apart. And the moment you have the number, it is already out of date, because maximal strength drifts day to day with sleep, food, and stress.

There is a better way, and you are almost certainly generating the data for it on every set already. It is called the estimated one-rep max, or e1RM, and once you understand it you can track your strength honestly without ever risking a maximal attempt.

## What an estimated 1RM actually is

An estimated 1RM predicts the most you could lift once from a set you already did for multiple reps. Lift 100kg for 5 reps and a formula converts that submaximal set into an estimated single, somewhere around 112 to 116kg depending on the equation.

The logic is simple: the more reps you can do with a given weight, the further that weight is below your true max, and the relationship between reps and percentage of max is predictable enough to model. That is the whole idea. Reps to failure are a proxy for how close a load is to your ceiling.

_Image: estimated 1RM on the exercise detail screen_



## The formulas, and which to trust

Two equations do most of the work in strength apps and spreadsheets.

The **Epley** formula: 1RM = weight × (1 + reps / 30). The **Brzycki** formula: 1RM = weight × 36 / (37 − reps).

They agree closely at low reps and diverge as reps climb. At a single rep both correctly return the weight itself. At 10 reps Epley tends to estimate slightly higher than Brzycki, and by 15 or 20 reps they scatter widely, which points at the one rule that matters most.

**Accuracy lives at low reps.** When researchers compared the popular prediction equations against measured one-rep maxes in the bench press, squat, and deadlift, the estimates were good but the error grew as the rep count rose [1]. A set of 3 to 6 reps gives a far tighter estimate than a set of 12 to 15, because a high-rep set brings in muscular endurance, pacing, and pain tolerance, which are not the same trait as maximal strength [2].

So the practical rule is: if you care about the number, estimate it from a hard set of roughly 5 reps or fewer, taken close to failure. Estimate it from a casual set of 15 and you are really measuring your endurance, not your max.

## Why estimating beats testing for most lifters

A true one-rep max is a single noisy data point. An estimated 1RM, pulled from a working set you were going to do anyway, is a data point you generate every single session, for every lift, at no extra cost and no extra risk.

That changes what you can see. One tested max tells you where you were on one day. A running e1RM trend tells you whether you are actually getting stronger, week over week, which is the only question that matters.

It also keeps you healthy. Maximal singles carry the highest injury risk and the longest recovery cost of anything you do in the gym, and stacking them frequently is how people stall or get hurt. Estimating from submaximal work sidesteps that entirely.

## How to actually use it

**Track the trend, not the daily number.** Any single e1RM will wobble. The line over a training block is the signal. If it is climbing, your program is working, even on days the top set felt heavy.

**Program your percentages off it.** Most strength templates are written as percentages of 1RM. You can drive those percentages off your estimate and update it as it rises, instead of re-testing a true max every few weeks.

**Compare like with like.** An e1RM from a set of 5 near failure is not the same quality of estimate as one from a set of 12 left with reps in the tank. Keep your estimating sets in a consistent rep range so the trend stays clean.

## Where tracking comes in

The catch with estimated 1RM is the arithmetic. Nobody wants to run Epley in their head between sets, and doing it by hand for every lift across a block is exactly the kind of chore that quietly does not happen.

This is why Setkord computes an estimated 1RM from every weighted set you log, automatically, and charts it over time on each exercise's detail screen. You lift, you log the set, and the strength trend builds itself, so you can see whether the big lifts are actually moving without ever setting up a maximal single.

Because the estimate comes from your real working sets, it also stays honest to how you actually train, rather than to one heroic gym day that may never repeat.

## Wrapping up

You do not need to max out to know you are getting stronger. Take a hard set of about five reps or fewer, let a formula turn it into an estimated single, and watch the trend rather than any one number. It is safer, it is repeatable, and it gives you a strength signal on every lift, every session.

Log every set and let the numbers build themselves, with [Setkord](https://setkord.com/).

## References


- LeSuer DA, McCormick JH, Mayhew JL, Wasserstein RL, Arnold MD. The Accuracy of Prediction Equations for Estimating 1-RM Performance in the Bench Press, Squat, and Deadlift. Journal of Strength and Conditioning Research. 1997;11(4):211-213. [Link](https://journals.lww.com/nsca-jscr/abstract/1997/11000/the_accuracy_of_prediction_equations_for.1.aspx)
- Reynolds JM, Gordon TJ, Robergs RA. Prediction of One Repetition Maximum Strength From Multiple Repetition Maximum Testing and Anthropometry. Journal of Strength and Conditioning Research. 2006;20(3):584-592. [Link](https://pubmed.ncbi.nlm.nih.gov/16937972/)
- Brzycki M. Strength Testing: Predicting a One-Rep Max from Reps-to-Fatigue. Journal of Physical Education, Recreation & Dance. 1993;64(1):88-90. [Link](https://www.tandfonline.com/doi/abs/10.1080/07303084.1993.10606684)
- Mayhew JL, Ball TE, Arnold MD, Bowen JC. Relative Muscular Endurance Performance as a Predictor of Bench Press Strength in College Men and Women. Journal of Applied Sport Science Research. 1992;6(4):200-206. [Link](https://pubmed.ncbi.nlm.nih.gov/?term=Mayhew+relative+muscular+endurance+bench+press+strength)

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/blog/estimated-1rm-train-off-your-numbers
