[Back to blog](https://setkord.com/blog)

# How to Build a Workout Routine: A Complete Guide for Lifters

2 September 2026 · Mark Stent

- programs
- training



To build a workout routine, pick a training split that matches how many days a week you can lift, choose a few compound lifts plus a handful of accessories per session, aim for roughly 10 to 20 hard sets per muscle group per week, and add weight or reps over time. That is the entire job: frequency, exercise selection, volume, and progression. Everything else is detail, and most people drown in the detail before they get the four basics right.

This is the guide I wish someone had handed me when I started - the structure first, then the choices inside it.

## The four decisions that make a routine

A good routine is not a magic list of exercises. It is four decisions, made in order:


- **How many days a week can you realistically train?** Not in a perfect week - in a normal one.
- **Which split fits those days?** The split just decides which muscles you hit on which day.
- **What do you do each session?** A couple of compound lifts to drive the session, then accessories to fill the gaps.
- **How do you get better week to week?** This is [progressive overload](https://setkord.com/blog/progressive-overload), and it is the part that actually causes growth.

Get these four right and almost any sensible plan works. Get them wrong and the fanciest program on the internet still fails you.

## Step 1: Decide how many days a week

Your training days decide everything downstream, so be honest here. Two to three days a week is plenty to make real progress as a beginner. Four is a sweet spot for most people with jobs and lives. Five or six is for people whose recovery, sleep, and schedule can genuinely support it.

The best routine is the one you actually complete. A four-day plan you finish beats a six-day plan you bail on by Thursday. I go deeper on this in [how many days a week you should train](https://setkord.com/blog/how-many-days-a-week-to-train), but the short version: pick the number you can hit in a bad week, not a good one.

## Step 2: Pick a split that fits those days

The "split" is just how you divide your body across the week. Match it to your days:

|Days per week |Best-fit split |Why |
|---|---|---|
|2 - 3 |[Full body](https://setkord.com/blog/full-body-workout-routine) |Hits everything each session, so missing a day costs less |
|3 (strength focus) |[5x5](https://setkord.com/blog/5x5-workout) |Simple, heavy, brutally effective for beginners |
|4 |[Upper / lower](https://setkord.com/blog/upper-lower-split) |Two upper, two lower - great balance of frequency and recovery |
|5 - 6 |[Push / pull / legs](https://setkord.com/blog/push-pull-legs) |High frequency and volume for more advanced lifters |

Notice there is no single "best" split. There is a best split for your number of days. Start from the days, not from the split you saw on YouTube.

## Step 3: Choose your exercises

Every session follows the same shape: **compounds first, accessories after.**


- **Compound lifts** move multiple joints and load the most muscle: squat, deadlift, bench press, overhead press, row, pull-up. These are the engine of the routine. Put them first while you are fresh.
- **Accessory / isolation work** fills in what the compounds miss or under-trains: curls, triceps, lateral raises, hamstring curls, calves, abs.

A clean session is two to four compound-ish movements plus two to four accessories. You do not need twelve exercises. You need a few done well and pushed hard.

Pick movements you can perform with good form and progress over time. A lift you cannot load safely is not building anything.

## Step 4: Sets, reps, and weekly volume

This is where people overthink hardest. Keep it simple:


- **Reps:** roughly 5 to 12 for most working sets. Lower reps (3 to 6) skew toward strength, higher reps (8 to 15) skew toward size, but both build both. There is no magic number.
- **Sets:** the number that matters is **weekly sets per muscle group**, not sets per session. Aim for about **10 to 20 hard sets per muscle group per week** and let your split spread them out.
- **Effort:** those sets need to be genuinely hard - stopping a rep or two short of failure on most sets.

I break the volume question down properly in [training volume for muscle growth](https://setkord.com/blog/training-volume-for-muscle-growth) and [how many sets per week to build muscle](https://setkord.com/blog/how-many-sets-per-week-to-build-muscle). If you only remember one thing: hard sets per week, not exercises per session, is the lever.

## Step 5: Progress week to week

A routine that never changes is not a routine, it is a habit that stops working. [Progressive overload](https://setkord.com/blog/progressive-overload) means doing measurably more over time - more weight, more reps, or better-controlled sets - so your body has a reason to adapt.

The simplest version: when you hit the top of your rep range on all sets, add a little weight next time and start climbing again. That is it. Small, constant, tracked progress is what separates people who get stronger from people who just show up.

Which is exactly why you have to write it down. A number you half-remember is a plateau you cannot see coming.

## A simple starting routine

If you want to stop reading and just start, here is a solid four-day [upper/lower](https://setkord.com/blog/upper-lower-split) week:

|Day |Focus |Example lifts |
|---|---|---|
|Mon |Upper |Bench, row, overhead press, pull-up, curls |
|Tue |Lower |Squat, Romanian deadlift, leg press, calves |
|Thu |Upper |Overhead press, pull-up, incline bench, row, triceps |
|Fri |Lower |Deadlift, front squat, leg curl, calves |

Add weight or reps whenever a session feels comfortably within range. Run it for months, not weeks.

## How to build your routine in Setkord

A routine only works if you actually run the same plan and beat your last numbers. That is what Setkord is built for:


- **Save your split as routines**, or start from the built-in program library, and pick up where you left off in a tap.
- **Your last weight and reps pre-fill** on every set, so progressive overload is obvious instead of guesswork.
- **Personal records and your [estimated 1RM](https://setkord.com/blog/estimated-1rm-train-off-your-numbers) are tracked automatically**, so you can see progress - and a stall - coming.
- It **works fully offline** in any gym with no signal, and the core is **free forever**.

You design the plan; Setkord keeps the score.

## FAQ

**How many exercises should a workout have?** Around four to eight. Two to four compound lifts to drive the session, then two to four accessories for what they miss. More than that and quality usually drops before the last exercises.

**What is the best workout split for beginners?** A [full-body](https://setkord.com/blog/full-body-workout-routine) routine two to three days a week, or a [5x5](https://setkord.com/blog/5x5-workout) if you want a heavy strength focus. Both give each muscle high frequency and are hard to mess up.

**How long should a workout routine be before I change it?** Months, not weeks. Change the plan when progress genuinely stalls after honest effort and recovery, not because you are bored. Consistency on one plan beats constant program-hopping.

**Do I need different routines to build muscle vs strength?** Less than you think. Strength work skews to lower reps and heavier weight, size work to higher reps and more total volume, but both build both. Pick the emphasis, keep progressing, and eat and sleep enough to recover.

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/blog/how-to-build-a-workout-routine
