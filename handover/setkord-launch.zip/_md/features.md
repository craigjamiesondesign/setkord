# Everything Setkord does

The complete feature list, by category. A fast, accessible strength log with the depth serious lifters actually use - and none of the clutter they don't.

The core is free forever. Pro removes the limits and adds the deeper analysis, sharing and import tools - marked below.[Download free](https://apps.apple.com/app/id6799150529)

- [Logging](#logging)
- [Exercises](#exercises)
- [Routines & programs](#routines-and-programs)
- [Progress & stats](#progress-and-stats)
- [Insights](#insights)
- [History](#history)
- [Body measurements](#body-measurements)
- [Sharing](#sharing)
- [Import & export](#import-and-export)
- [Sync & offline](#sync-and-offline)
- [Widgets, Siri & reminders](#widgets-siri-and-reminders)
- [Apple Health](#apple-health)
- [Account & preferences](#account-and-preferences)
- [Accessibility](#accessibility)
- [On the web](#on-the-web)

## Logging

Everything about capturing a set is built to take seconds, not menus.

-

### Unlimited workouts

Log as much as you train. There is no cap on sessions, on Free or Pro.
-

### Three set types

Weight x reps, bodyweight (reps only), or timed (mm:ss) for planks, carries and cardio.
-

### Fast set entry

Log weight x reps in a tap or two, with your last session's numbers pre-filled.
-

### Per-set notes

Drop a note on any set - "felt easy", "left elbow twinge" - and see it inline later.
-

### RPE per set

An optional 1-5 effort rating on each set, switched on in preferences.
-

### Warm-up sets

Flag warm-ups so they never inflate your working volume or steal a PR.
-

### Warm-up calculator

Builds a percentage ramp to your working weight, rounded to loadable plates or dumbbells.
-

### Plate calculator

Shows exactly what to load per side of the bar for any target weight, in kg or lb.
-

### Supersets & giant sets

Group exercises with clear on-screen separation so alternating stays as fast as a straight set.
-

### Reorder exercises

Drag exercises into any order, mid-workout.
-

### Per-exercise rest override

Give one exercise its own rest length without touching your default.
-

### Automatic rest timer

Starts itself when you log a set, keeps running when your phone locks, and notifies you when it's done.
-

### Live session timer

A running clock for the whole workout - on if you want it, off if you don't.
-

### Back-date a workout

Log a session on a past day for when you forgot to track it in the moment.
-

### Minimize & resume

Step out of a workout mid-session and pick it back up from the Train screen.
-

### Dumbbell handling

Enter the combined weight you actually lifted; volume is always tracked as true load.
-

### Distance tracking

Optionally log distance on loaded carries and cardio - in metres/km or feet/miles - as its own record, never folded into your lifting volume. Off by default.
-

### Save as a routine

Turn any finished workout into a reusable routine in one tap.
-

### Finish summary

A clean end-of-session recap - total volume (or cardio time), sets, time, and any PRs - and share it straight away as a card, full image or PDF.
-

### Works offline

Every set logs instantly with no signal and syncs the moment you're back online.

_Image: Setkord logging a set during a workout_

## Exercises

A big, clean catalog - and room for everything you actually train.

-

### 441-exercise catalog

Browse by muscle group or search; the library is updated over the air, no app update needed.
-

### Unlimited custom exercises

Type any exercise name and it's added - tracked like a first-class movement.
-

### Manage your exercises

Rename a lift in place, delete a custom one, or flag it as a two-dumbbell exercise - all from one place.
-

### Curate your catalog

Hide any built-in you never use, or browse only your own exercises for a clean, personal list. An explicit search still finds everything.
-

### Merge exercises

Fold one exercise's history into another to clean up duplicates.
-

### Group variations

Roll variations ("rdl" into "Romanian Deadlift") under one lift for stats, with a rolled-up-or-individual toggle.
-

### Per-exercise detail

Per-lift charts for estimated 1RM, heaviest weight and volume over time, with your full set history.

## Routines & programs

Build your training once and start it in a tap - even with no signal.

-

### Build routines

Pick exercises, set target sets, reps and supersets, and reuse them session after session. Free covers up to 7 routines; Pro unlocks unlimited routines.
-

### Routine folders

Organise routines into groups so your training stays tidy.
-

### Routine templates

Start from ready-made routine templates instead of a blank slate.
-

### Start empty or from a routine

Launch a workout blank, or from a saved routine pre-filled and ready to log - fully offline.
-

### Programs to follow

A curated library of 36 proven multi-day programs - from Starting Strength and 5/3/1 to PPL, glute-focused and fat-loss plans - updated over the air, that you can start or save to your own.
-

### Filter programs by goal

Browse the built-in library by goal - build muscle, strength, fat loss or general - with the level and day count on every card.
-

### Programs

Group your routines into a program - push, pull, legs - so a whole block lives in one place.

_Image: Setkord routines and programs on iPhone_

## Progress & stats

Every set you log feeds your numbers automatically. See the trend, not just today.

-

### Training totals

Volume, workouts, sets and your streak at a glance, with period-over-period trend arrows.
-

### Automatic personal records

PRs are detected as you log - against your all-time bests even on Free - and celebrated the instant you finish.
-

### Estimated 1RM

An estimated one-rep max for every lift, so you can watch your strength climb.
-

### Muscle balance

Working sets per body part, with gentle flags for the areas you've been skipping.
-

### Top exercises

Your most-trained lifts, ranked, so you can see where your work is actually going.
-

### Weekly volume

A snapshot of total weight moved per week.
-

### Cardio conditioning

Log cardio in minutes and see your weekly conditioning time and an 8-week trend - kept in its own lane, never mixed into your lifting volume.

_Image: Setkord progress screen with estimated 1RM trends_

## Insights

The deep analysis of your training over time.

-

### Volume trendPro

Total weight lifted per week, charted over your whole history.
-

### Training consistencyPro

How regularly you're training - workouts per week and active weeks.
-

### Rest ratioPro

How much of your week is training versus recovery, charted over time.
-

### Strength progressionPro

Estimated-1RM lines for your top lifts.
-

### Any-lift progressionPro

Pick any exercise and see its estimated-1RM history.
-

### Period comparisonPro

This period versus the previous one, side by side.
-

### Plateau & fatigue signalsPro

Flags when a lift has stalled or your overall output is dropping.
-

### PR timelinePro

Your personal records plotted over time.

## History

Your full training record, exactly the way you want it.

-

### Workout history

Every session with full per-workout detail. Free shows the last 12 months; Pro unlocks all-time (list, stats and PRs).
-

### List & calendar views

Scroll your sessions as a list, or see your training as a month grid.
-

### Search

Find any past session by workout name or exercise.
-

### Date-range filter

Narrow history to this year or a custom from/to range.
-

### Edit anything

Open any past workout to rename it in place, then view, edit or delete its exercises, sets and notes.

## Body measurements

Track the numbers beyond the bar.

-

### Log your metrics

Weight, body-fat %, and tape measurements (neck, chest, waist, hips, arms, thighs, calves), in your units.
-

### Trend charts

Each metric charted over time, with a range filter to zoom in or out.
-

### Full control

Add, edit or delete any measurement entry whenever you like.

## Sharing

Show your work - and bring your training partners with you.

-

### Share a workout image

Turn a session into a branded card - your stats over your own photo, or a bold stat card - with a live preview before you post it anywhere.
-

### Share a workout PDFPro

Export the complete session - every exercise and set - as a branded PDF document.
-

### Share a routinePro

Send a routine or a whole group to another lifter via a link; they tap to import it. Creating a share is Pro; importing is open to everyone.

## Import & export

Your data works wherever you do, and it's always yours.

-

### Import from Strong & Hevy

Bring your history across via CSV, so you start with your real numbers instead of a blank slate.
-

### Export your data

Download your entire training history to CSV any time. You own your data - Setkord just keeps it for you.
-

### Reset your data

Wipe your workouts, routines and PRs while keeping your account, if you ever want a clean start.

## Sync & offline

Local-first: instant on your phone, in sync everywhere.

-

### Local-first & offline

The app works fully offline and never blocks on a connection - no spinners, no lost sets.
-

### Automatic sync

Your training syncs in the background across your devices and to the web the moment you're online.

## Widgets, Siri & reminders

Setkord reaches out from the home screen, lock screen and Siri.

-

### Home & lock-screen widgets

Your week streak and this week's workout count, glanceable without opening the app.
-

### Live Activity

Your active workout and rest countdown on the lock screen and Dynamic Island.
-

### Start with Siri

"Hey Siri, start my Setkord workout" - or a Shortcut / Control Center button - starts or resumes a session, offline.
-

### Training reminders

A friendly nudge on the days and time you choose. On your phone only, opt-in, off by default.

_Image: Setkord widget on the iPhone Home Screen_

## Apple Health

Your lifting counts toward your day.

-

### Save workouts to Apple Health

Finished sessions write to Apple Health as strength training (one-way, opt-in), with an Open in Health shortcut.

## Account & preferences

Set it up the way you train.

-

### Email or Google sign-in

Create an account in seconds - no card required to start.
-

### Units

Train in kilograms or pounds; everything follows your choice.
-

### Default rest length

Set the rest time that fits your training, from 30 seconds up.
-

### Your plan

Setkord is free to download and use. Pro is an optional monthly or annual subscription that you manage and restore from inside the app.
-

### Email updates

Opt in to product news and tips - unticked by default, unsubscribe any time.
-

### Account controls

Edit your name, replay the app tour, log out, or delete your account and its data outright.

## Accessibility

Built to be readable and usable from day one, not bolted on later.

-

### Dynamic Type

The whole app scales with your iOS text-size setting, and the hierarchy holds at every size.
-

### High-contrast mode

A higher-contrast palette for surfaces, borders and text when you need it.
-

### Text-size presets

In-app Small to Huge presets on top of the system setting.
-

### VoiceOver

Labelled controls and actions throughout, including charts and destructive actions.

## On the web

setkord.com is more than a landing page - sign in and manage your training in a browser.

-

### Your account, in a browser

Every signed-in lifter can manage their profile, preferences and password at setkord.com.
-

### Browse your dataPro

View your history, routines, programs, custom exercises and body measurements on the web.
-

### Author on the webPro

Create and edit routines (with per-set targets and supersets), programs and custom exercises in the browser - and it syncs straight to your phone.

Want the short version? [See the highlights](https://setkord.com/).

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/features
