[Back to blog](https://setkord.com/blog)

# The 5x5 Workout: A Complete Guide to Sets, Progression, and Who It's For

2 September 2026 · Mark Stent

- programs
- strength
- beginner



A 5x5 workout is five sets of five reps on a handful of big barbell lifts, done three times a week, adding a little weight every single session. That is the whole idea: a small number of compound lifts, five hard sets each, and relentless linear progression. It is the most reliable way for a beginner or returning lifter to get strong fast, and it is popular for one honest reason - it works, and it is almost impossible to overcomplicate.

## What is a 5x5 workout?

"5x5" means **5 sets of 5 reps** at the same weight. You pick a handful of compound barbell movements - squat, bench, row, overhead press, deadlift - and perform five sets of five on each. Five sets of five (25 reps) is enough volume to build real strength and muscle, and five reps is heavy enough to drive strength without turning every session into a grind.

The magic is not the rep scheme. It is the **progression rule**: you add weight every workout. That small, constant push is what makes strength climb week after week.

## The 5x5 workout (the classic A/B split)

The best-known version runs two alternating workouts, three days a week (for example Monday, Wednesday, Friday):

| |Workout A |Workout B |
|---|---|---|
|Lift 1 |Squat - 5x5 |Squat - 5x5 |
|Lift 2 |Bench Press - 5x5 |Overhead Press - 5x5 |
|Lift 3 |Barbell Row - 5x5 |Deadlift - 1x5 |

You alternate A, B, A one week, then B, A, B the next. **You squat every session** - three times a week - which is exactly why beginners progress so quickly on it. Deadlift is a single heavy set of five, because five sets of deadlifts three times a week is more than most people can recover from.

## How the progression works

This is the part that matters:


- **Add weight every workout you succeed on** - typically **2.5 kg / 5 lb** on the upper-body lifts and squat, and 2.5 kg or more on deadlift.
- **Success = all 5 sets of 5** at that weight. Get all reps, the weight goes up next time.
- **Stall = fail to get 5x5 for three sessions in a row on a lift.** When that happens, **deload** that lift by about 10% and climb back up - the second run past the sticking point almost always succeeds.

Start lighter than your ego wants. The whole point of linear progression is that the first few weeks feel easy so the later weeks are possible. If you start at your limit, you get two good sessions and then you are stalling.

## The main versions

Not all "5x5" programs are the same:


- **StrongLifts 5x5 / Starting-Strength-style** - the beginner A/B split above, adding weight every session. Best for your first several months of serious lifting.
- **Madcow 5x5** - an intermediate version. Progression moves to **once a week** and the five sets **ramp** in weight (lighter to a top set), because a true beginner's every-session jumps stop working once you are strong. Switch to this when linear progression finally dies.
- **Bill Starr 5x5** - the original 1970s template Madcow is based on: a heavy/light/medium weekly structure for athletes.

If you are new, run the beginner A/B version first. Only move to Madcow when adding weight every session genuinely stops working.

## Who 5x5 is for (and who it isn't)

**It is a great fit if you are:** a beginner or coming back after time off, want to get strong on the main barbell lifts, and like a simple plan you do not have to think about.

**Look elsewhere if you are:** an advanced lifter (you will stall almost immediately - you need periodised or higher-volume programming), chasing mostly hypertrophy/aesthetics (a [higher-volume, more varied plan built around weekly sets per muscle](https://setkord.com/blog/how-many-sets-per-week-to-build-muscle) fits better), or training around an injury that a heavy triple-weekly squat would aggravate.

## Common 5x5 mistakes


- **Starting too heavy.** You skip the easy weeks that make the program work.
- **Adding weight after a failed session.** The rule is: add weight only when you completed all five sets.
- **Skipping the deload.** Grinding a stalled lift for weeks just digs the hole deeper - deload 10% and run it back.
- **Not eating or sleeping enough.** Progression every session is a real recovery demand. If the bar stops moving, look at your food and sleep before you blame the program.
- **Not tracking it.** 5x5 lives or dies on knowing exactly what you lifted last time and hitting the next jump. A number you half-remember is a stall waiting to happen.

## How to run 5x5 in Setkord

5x5 is a tracking program - the last mistake above is the one that quietly kills most people's runs. Setkord is built for exactly this:


- Save the A/B split as two **routines** (or start it from the built-in program library) and pick up where you left off in a tap.
- Your **last weight and reps pre-fill** on every set, so you always know the next jump.
- **Personal records are detected automatically**, and your [estimated 1RM](https://setkord.com/blog/estimated-1rm-train-off-your-numbers) is charted so you can watch strength climb and see a stall coming before it stops you.

You focus on adding weight; Setkord keeps the score.

## FAQ

**Is 5x5 good for building muscle?** Yes - five hard sets of five on compound lifts builds size as well as strength, especially for a beginner. If pure aesthetics are the goal, a higher-volume, more varied plan will eventually do more, but 5x5 is a strong foundation.

**How long should I run 5x5?** As long as you keep adding weight - usually several months for a beginner. When linear progression stalls for good (even after deloads), move to an intermediate version like Madcow or a periodised program.

**How long does a 5x5 workout take?** About 45-60 minutes, mostly rest. Five heavy sets need real rest between them - [2 to 5 minutes for the big lifts](https://setkord.com/blog/how-long-to-rest-between-sets).

**Can I add curls and accessories?** Yes, a little. A few sets of arms, calves, or abs at the end is fine. Keep it minimal - the compound lifts and the progression are what drive the results.

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/blog/5x5-workout
