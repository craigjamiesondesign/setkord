[Back to blog](https://setkord.com/blog)

# How to Track Lifting Progress (Beyond Just Adding Weight)

2 September 2026 · Mark Stent

- tracking
- progress



The clearest way to track lifting progress is estimated 1RM - a single strength number worked out from the weight and reps of your best sets - charted over time. It rises even when the weight on the bar doesn't, because getting more reps at the same load is progress too. Watch that trend line, back it up with volume and rep PRs, and you can see strength climbing under the day-to-day noise.

## Why "did the bar get heavier?" isn't enough

Progress is not just adding plates. If you squatted 100 kg for 5 last month and 100 kg for 8 today, you got stronger - the bar weight never moved, but you clearly progressed. Judging progress by top-set weight alone misses this entirely and makes you feel stuck when you aren't.

You need a measure that captures both more weight and more reps. That measure is estimated 1RM.

## Estimated 1RM: the single best progress number

Your one-rep max is the most weight you can lift once, but testing it is risky and tiring, so you don't want to actually do it often. Instead, an estimated 1RM is calculated from a normal working set - the weight and the reps - using a standard formula.

100 kg for 5 estimates roughly a 113 kg max. 100 kg for 8 estimates about 124 kg. Same bar weight, a clearly higher estimate, because you did more reps. Chart that estimate across months and you get one clean line for "am I getting stronger?".

I go deeper on how to use it in [Estimated 1RM: Train Off Your Numbers](https://setkord.com/blog/estimated-1rm-train-off-your-numbers). The short version: it turns every hard set into a data point, so you don't have to max out to know you're progressing.

## The four things worth tracking for progress

Estimated 1RM is the headline, but a few other measures fill in the picture:

|Measure |What it tells you |When it's the key signal |
|---|---|---|
|Estimated 1RM |Overall strength trend |Always - the main number |
|Rep PRs |Most reps at a given weight |When the bar weight is parked but reps climb |
|Training volume |Total hard sets/load per muscle |When training for size, not just max strength |
|Bodyweight / measurements |Body composition change |Cutting or bulking, or checking size gains |

Strength-focused? Lead with estimated 1RM and rep PRs. Size-focused? Weight [training volume](https://setkord.com/blog/how-to-track-training-volume) and body measurements more heavily, because [volume drives muscle growth](https://setkord.com/blog/training-volume-for-muscle-growth).

## How to read the trend, not the day

The single biggest mistake in tracking progress is reacting to one session. Strength is noisy day to day - sleep, stress, food and even the time of day all move your numbers a few percent.


- **Look at the trend over weeks, not one bad Tuesday.** A single flat or down session means nothing on its own.
- **A real stall is three or four sessions going nowhere**, not one. That's when you change something - deload, adjust volume, check recovery.
- **Expect progress to slow as you get more advanced.** A beginner adds weight almost every session; an experienced lifter measures progress over months. That's not failure, it's normal, and it's exactly why a charted trend matters more the longer you train.

This is [progressive overload](https://setkord.com/blog/progressive-overload) read at the right zoom level: session to session you apply it, but you judge it over blocks.

## Don't forget the honest inputs

A progress chart is only as good as the numbers under it.


- **Log in the gym**, so the reps are real, not a flattering memory.
- **Record effort** ([RPE or RIR](https://setkord.com/blog/rpe-vs-rir)), because 100 kg for 5 at 3 reps in reserve and 100 kg for 5 at failure are very different progress signals from the same numbers.
- **Count true load**, both dumbbells included, or your estimates and volume read as half of what you actually did.

The full method sits in [how to track your workouts](https://setkord.com/blog/how-to-track-workouts).

## How Setkord tracks this for you

Working out estimated 1RMs and trend lines by hand is exactly the arithmetic people quit over, so Setkord does all of it from the sets you already log:


- **Estimated 1RM is calculated and charted automatically** for every lift, so your strength trend is a line you can read, not a spreadsheet you have to build.
- **Personal records are detected automatically** - both weight PRs and rep PRs - so the day you beat 100 kg for 8, you know it.
- **Volume and muscle-balance stats** track the size side, and **Insights trends (Pro)** surface the slow multi-month patterns you'd never spot session to session.
- **Body measurements** sit alongside the lifts, so you can line up strength, size and bodyweight together.
- **Import from Strong or Hevy** brings your history so your trend starts with data already in it, and it all **works fully offline** with a **free forever core**.

After thirty years of tracking my own lifts, the estimated-1RM chart is the view I check most - it's the honest answer to "is this working?" - so I built it to be the first thing you see.

## FAQ

**What's the best way to measure lifting progress?** Estimated 1RM charted over time. It captures both more weight and more reps from your normal working sets, so it rises even when the bar weight is parked - which top-set weight alone completely misses.

**How often should I test my one-rep max?** Rarely, if ever. Actual max testing is risky and fatiguing. Estimated 1RM from your regular working sets gives you the same strength signal without maxing out, so most lifters never need a true 1RM test.

**Why does my progress feel slower than it used to?** Because it is, and that's normal. Beginners add weight almost every session; experienced lifters measure progress over months. It's exactly why a charted trend matters more the longer you train - it shows the slow climb the day-to-day can't.

**Should I track bodyweight and measurements too?** Yes, especially if you're training for size or changing body composition. Strength numbers tell you about performance; bodyweight and measurements tell you about size. Tracking both lets you line up what you did against what your body actually did.

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/blog/how-to-track-lifting-progress
