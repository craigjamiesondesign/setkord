[Back to blog](https://setkord.com/blog)

# How to Track Training Volume (Sets, Reps and Tonnage Explained)

2 September 2026 · Mark Stent

- tracking
- progress



The simplest reliable way to track training volume is to count your hard working sets per muscle group per week. For most lifters that number lands somewhere around 10 to 20 sets per muscle per week, and watching it trend up over time is a cleaner signal of progress than any single tonnage figure. Set counting is the metric that actually predicts muscle growth, so start there.

## What "training volume" actually means

Volume gets used for three different things, which is why it confuses people.

|Measure |What it is |Best for |
|---|---|---|
|Hard sets per muscle / week |Count of working sets that took a muscle close to failure |Tracking whether you're doing enough to grow |
|Tonnage (volume load) |Sets x reps x weight |Comparing total work across sessions of the same lift |
|Reps per muscle / week |Total working reps |A rough middle ground; less used |

Set counting wins for day-to-day tracking because it maps most directly onto muscle growth and is the easiest to plan around. Tonnage is useful in a narrower way - comparing how much total work you did on, say, bench press this week versus last - but it can mislead across different rep ranges, because five heavy singles and fifty light reps can produce the same tonnage from wildly different sessions.

## How to count sets the right way

Two rules keep set counting honest:


- **Only count hard sets.** A working set taken to within a few reps of failure counts. Warm-ups do not. A set you dogged through at 50% effort barely does.
- **Count per muscle, not per exercise.** A barbell row trains your back, but it also gives your biceps meaningful work. A bench press hits chest, front delts and triceps. When you tally weekly volume, an exercise can contribute to more than one muscle's count.

So a back day of 4 sets of rows, 4 of pulldowns and 3 of face pulls is roughly 11 hard sets for your back that session. Add the pulling you do on other days and you have your weekly back volume.

## How much volume you actually need

The honest, evidence-informed ranges most lifters do well on:


- **Minimum to grow: around 10 hard sets per muscle per week.** Below this, most people are maintaining rather than building.
- **Productive range: roughly 10 to 20 sets per muscle per week.** Most trainees make their best progress somewhere in here.
- **Diminishing returns and rising fatigue above ~20 sets** for most people, though advanced lifters tolerate and sometimes need more.

These are starting points, not laws. I break the muscle-growth side of this down fully in [Training Volume for Muscle Growth](https://setkord.com/blog/training-volume-for-muscle-growth) and in [how many sets per week to build muscle](https://setkord.com/blog/how-many-sets-per-week-to-build-muscle). The tracking principle is the same whatever your exact number: pick a target, log against it, adjust from what you see.

## When tonnage is worth tracking

Tonnage (sets x reps x weight) earns its place in one situation: comparing your total work on a single lift or session over time, at a similar rep range.

If your squat tonnage climbs from 3,000 kg to 3,400 kg across a block at the same rough intensity, you did more total work, and that is real progress you can see. Just don't compare tonnage across different rep ranges or different exercises and expect it to mean much - it flattens a heavy triple and a light set of twenty into the same headline number, and those are not the same stimulus.

## A note on load: always count the true weight

One trap that quietly corrupts volume tracking is dumbbells. A 20 kg dumbbell in each hand is 40 kg of load on the muscle, not 20. Whatever you track, make sure your total-load figure counts both hands, or your volume will read as half of what you actually did. Setkord always counts true load (both dumbbells) for volume and stats, regardless of how the number is displayed.

## How Setkord tracks this for you

Counting sets by hand every week is exactly the kind of admin that makes people quit tracking. Setkord does it from the sets you already log:


- **Volume and muscle-balance stats** tally your hard working sets per muscle automatically, and show where your work is actually landing - so you can see at a glance that back is getting 16 sets while rear delts get two.
- **Warm-ups are excluded** from your working volume, so the number reflects the sets that actually drive growth.
- **True load is always used** (both dumbbells counted) for volume and tonnage, so the figure is honest.
- **Insights trends (Pro)** show volume climbing or sliding over months, which is where a slow drift you'd never notice session to session becomes obvious.
- It all **works fully offline** and the core is **free forever**.

The point is that you plan your sets, and Setkord keeps the running total, so "am I doing enough for my back?" becomes a number you can read instead of a guess.

## FAQ

**Is it better to track sets or tonnage?** Sets per muscle per week for tracking whether you're growing, because set count maps most directly onto muscle growth. Tonnage is a useful secondary metric for comparing total work on a single lift over time, but it misleads across different rep ranges.

**How many sets per muscle per week should I aim for?** Most lifters make good progress in the range of 10 to 20 hard sets per muscle per week. Start around 10 to 12, and add sets over a block if you're recovering well and progress stalls.

**Do warm-up sets count toward volume?** No. Only hard working sets taken close to failure drive growth, so warm-ups should be flagged and excluded from your volume count. Setkord does this automatically.

**How do I count volume for an exercise that hits several muscles?** Let the set contribute to each muscle it meaningfully trains. A row counts toward back and, partly, biceps. This is why per-muscle tracking beats per-exercise counting for planning weekly volume.

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/blog/how-to-track-training-volume
