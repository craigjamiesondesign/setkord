# Contact

Report a bug, ask a question, or share an idea. We read every message and reply as soon as we can.

## Prefer email?

You can always reach us directly at [hello@setkord.com](mailto:hello@setkord.com). Support, press, and general enquiries all go to the same inbox. For what we are building and shipping, follow [@setkordapp on Instagram](https://www.instagram.com/setkordapp/).

## Privacy & data requests

To access, correct, export, or delete your data, use the controls in Profile inside the app, or email [hello@setkord.com](mailto:hello@setkord.com). See our [Privacy Policy](https://setkord.com/privacy) for details on your rights.

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/contact
