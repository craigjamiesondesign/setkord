[Back to blog](https://setkord.com/blog)

# How to Break a Lifting Plateau: A Practical Fix-It Guide

2 September 2026 · Mark Stent

- strength
- progression



To break a lifting plateau, back the weight off by about 10%, fix your recovery (food and sleep), then climb again while changing which progression lever you pull - reps instead of weight, or a different set or rep scheme. A plateau almost always means one of three things: you are under-recovered, you have run one progression method into the ground, or you are grinding a weight your ego picked instead of one you can build from. Grinding the same stuck weight harder is the one thing that never works.

A plateau is not a failure of effort. It is a signal, and it usually means [progressive overload](https://setkord.com/blog/progressive-overload) has stopped being recoverable. Here is how to read it and fix it, in order.

## First, is it actually a plateau?

One bad session is not a plateau. Neither is two. A real plateau is the same lift stuck at the same weight and reps for roughly three or more sessions, with no upward trend over several weeks.

Before you change anything, be honest about the trend. Day-to-day performance is noisy - sleep, stress, food, and time of day all move it. If the monthly trend is still creeping up, you are not plateaued, you are just having a normal off week. Keep going. Only the multi-week flat line counts.

## Step 1: Deload, don't grind

The instinct is to attack a stuck weight harder. It is exactly wrong. Grinding a stall digs the fatigue hole deeper and the bar moves less, not more.

Instead, deload: drop the weight on the stalled lift by about 10%, and climb back up over the next couple of sessions. The reason this works is that you were probably carrying accumulated fatigue that masked your real strength. The lighter weeks let you recover, and the second run at the sticking point - now fresh - almost always goes through. It feels like going backwards. It is the fastest way forwards.

## Step 2: Check recovery before you blame the program

Overload only works if you can recover from it. A stall is very often a recovery problem wearing a training problem's clothes.

Run this checklist before touching your program:

|Factor |The question |If the answer is no |
|---|---|---|
|Sleep |7 to 9 hours, most nights? |Fix this first - it is the biggest lever |
|Food |Eating enough, enough protein? |You cannot build muscle from a deficit of both |
|Stress |Life relatively under control? |Stress is systemic fatigue; expect slower progress |
|Consistency |Hitting sessions regularly? |An inconsistent program cannot stall or progress - it is just random |

If two or more of these are off, that is your plateau. No clever set-and-rep scheme fixes a lifter who is under-slept and under-fed.

## Step 3: Change the progression lever

If recovery is genuinely handled and a lift is still stuck, you have probably run one progression method until it died - usually adding weight every session.

Switch the lever:


- **Stuck adding weight?** Stop chasing a heavier bar and [add reps at the same weight instead](https://setkord.com/blog/progressive-overload-methods) until you top out a range, then add weight and drop back down.
- **Been running linear progression?** Move to double progression - the [full comparison is here](https://setkord.com/blog/linear-vs-double-progression). It is the single most common fix for an intermediate stall.
- **Range has drifted?** Tighten it up. A stuck weight through a half rep may be a fresh challenge through a full one.

Changing the lever gives your body a new demand to adapt to, which is the whole point. Same weight, same reps, same scheme, week after week, is the definition of no new demand.

## Step 4: Add variation and structure

If a lift is stubbornly stuck even after a deload and a lever change, the program itself may be too flat. Advanced lifters cannot progress in a straight line and need planned ups and downs.

Options, roughly in order of how big a change they are:


- **Rotate a close variation** for a few weeks - pause squats for squats, close-grip for bench - then return to the main lift refreshed and often stronger.
- **Adjust volume:** if you are doing very little, more hard sets may be the missing stimulus; if you are buried in volume, less may let you recover enough to progress. See [how many sets per week actually builds muscle](https://setkord.com/blog/how-many-sets-per-week-to-build-muscle).
- **Periodise:** plan lighter and heavier blocks instead of trying to beat a PR every week. Beyond the beginner stage, progress comes in waves, not a straight line.

## The one thing that never works

Adding weight to a lift you failed last session. The rule that makes any of this work is simple: you only earn the next jump when you actually completed the work at the current one. Skipping that rule turns every session into a grind and guarantees the stall gets worse. If you missed the reps, you have not earned the weight - repeat it, or deload, but do not add.

## How Setkord helps you spot and break plateaus

You cannot fix a plateau you cannot see, and most people cannot see theirs because they do not track closely enough to know the trend from the noise.


- **Last weight and reps pre-fill**, so you know exactly whether you actually beat last session or just felt like you did.
- The **estimated 1RM chart** turns a wall of numbers into a trend line - a flattening curve is a plateau forming, often before you feel it. See [how estimated 1RM works](https://setkord.com/blog/estimated-1rm-train-off-your-numbers).
- **Automatic PR detection** confirms real progress and stops you mistaking a good-feeling session for an actual one.
- **Insights (Pro)** surfaces plateau and fatigue signals directly, so the "is this a plateau?" question gets answered for you.

Fully offline, built for lifters, core free forever. You train; Setkord tells you when the trend turns.

## FAQ

**How long is too long to be stuck on a weight?** About three sessions with no progress, or two to three weeks with a flat trend, is a real plateau worth acting on. Less than that is normal week-to-week noise - do not overhaul your program over one bad session.

**Should I deload or just push through a plateau?** Deload. Pushing through a genuine plateau adds fatigue and makes it worse. Drop the weight about 10%, climb back over a couple of sessions, and the sticking point usually clears on the second, fresher run.

**Can eating more break a plateau?** Often, yes. If you are under-eating - especially on protein or total calories - your body has no surplus to build from, and no program will fix that. Sort sleep and food before you assume the training is the problem.

**Is a plateau a sign I am training wrong?** Not necessarily. Every lifter plateaus; the stronger you get, the sooner and more often it happens. It is a normal signal that you have outgrown your current approach and need to change a lever, not proof you did something wrong.

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/blog/how-to-break-a-lifting-plateau
