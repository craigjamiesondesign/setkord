# What's new

Every version of Setkord and what changed, newest first.

-

## v1.0.218 October 2026

Setkord 1.0.2 - accessibility fix: changing text size or contrast (in Profile or in iOS Settings) now updates every screen straight away instead of leaving parts of a screen on the old size until relaunch; weight and reps entry boxes grow to fit large text sizes.
-

## v1.0.18 October 2026

Setkord 1.0.1 - fairer progress: 'this week' now compares with the same point last week and charts no longer dip on an unfinished week; add a note to the set you just logged; 'No bar' option on the plate and warm-up calculators; gym playlist link in Profile.
-

## v1.0.07 October 2026

Setkord 1.0 - first App Store release. Fast set logging, routines and programs, PRs and progress, rest timer, plate and warm-up calculators, works offline. Setkord Pro subscriptions (monthly and annual).
-

## v0.1.023 August 2026

First TestFlight beta

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/whats-new
