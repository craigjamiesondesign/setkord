# Help centre

Everything you need to get the most out of Setkord.

- [DocumentationStep-by-step guides for logging, routines, supersets, and progress tracking.](https://setkord.com/help/docs)
- [Knowledge baseQuick answers to common questions about cost, platforms, privacy, and your data.](https://setkord.com/help/kb)
- [Report a bug or ask a questionCan't find an answer? Send us a message and we'll get back to you.](https://setkord.com/contact)
- [What's newThe release history - every version and what changed, newest first.](https://setkord.com/whats-new)

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/help
