[Back to documentation](https://setkord.com/help/docs)

# Frequently asked questions

## How much does it cost?

Setkord is free to download and use, and you will always be able to log your workouts for free. Setkord Pro, monthly or annual, adds unlimited routines, your full training history and advanced insights.

## What platform is Setkord on?

Setkord is on iPhone, available now on the App Store. There is no Android version yet - see below if you want to be notified.

## Is my data private?

Yes. Your training data is yours: we never sell it or use it for ads. For product analytics we only collect app usage events, tagged with a hashed device identifier rather than your name, email or account, and we look at them in aggregate. You can export or delete your data at any time from Profile. See our [Privacy policy](https://setkord.com/privacy) for the full detail on what we collect and why.

## Can I export my data?

Yes. Setkord includes a built-in export so you can take your full training history with you as a CSV file, whenever you want it.

## Can I rename or delete a built-in exercise?

Setkord ships a shared exercise catalog that everyone uses, so its **built-in exercises can't be renamed or deleted** - those options are greyed out. What you can do with a built-in is **hide** it, so it stops appearing in the picker and browse list (Profile - Preferences - Hidden exercises), while your logged history keeps it.

Your **own custom exercises** are marked with a "Custom" tag in Profile - Manage exercises, and those you can freely rename or delete.

If you want a built-in to show under your own name, add it as a custom exercise with the name you prefer, then use **Combine stats** on it (the ... menu in Manage exercises) to share one set of stats with the built-in. Both names stay, and either opens the same progress.

## How do I start fresh, or delete my data?

Two options, both in Profile:


- **Reset data** clears your logged sets, routines, and personal records but keeps your account and login, so you can start a clean training history without signing up again.
- **Delete account** is permanent. It removes your training data, routines, and personal records entirely, and there is no recovery after deletion.

## Is there an Android version?

Not yet. If you would like one, tell us through the [contact page](https://setkord.com/contact) and we will let you know if an Android version happens.

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/help/docs/faq
