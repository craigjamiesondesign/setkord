[Help centre](https://setkord.com/help)

# Knowledge base

Quick answers to the questions we hear most.

Coming soon

We're building out the knowledge base. In the meantime, see the [documentation](https://setkord.com/help/docs) or [ask us directly](https://setkord.com/contact).

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/help/kb
