[Back to blog](https://setkord.com/blog)

# Upper Lower Split: The Complete Guide and Weekly Plan

2 September 2026 · Mark Stent

- programs
- training



The upper lower split divides your training into upper-body days (chest, back, shoulders, arms) and lower-body days (quads, hamstrings, glutes, calves), usually run four days a week as two upper and two lower. It is the best-fit split for most people who can train four days, because it hits every muscle **twice a week** while leaving plenty of recovery between sessions. If you are not sure which split to run, this is the safe, high-return default.

## What is the upper lower split?

Two session types, alternated across the week:


- **Upper days:** all pressing and pulling for the torso and arms - bench, overhead press, rows, pull-ups, curls, triceps.
- **Lower days:** everything below the waist - squats, deadlifts, lunges, leg curls, calves.

Run four days a week, you get two of each. That means each muscle group is trained twice weekly, which research consistently shows is a strong frequency for building both size and strength - without the six-day commitment a [push pull legs split](https://setkord.com/blog/push-pull-legs) needs to reach the same frequency.

## The upper lower weekly plan

The standard four-day layout, with compounds leading and accessories following:

|Day |Focus |Example exercises |
|---|---|---|
|Mon |Upper A |Bench press, barbell row, overhead press, pull-up, barbell curl, triceps pushdown |
|Tue |Lower A |Squat, Romanian deadlift, leg press, leg curl, calf raise |
|Wed |Rest |- |
|Thu |Upper B |Overhead press, pull-up, incline bench, chest-supported row, hammer curl, overhead triceps extension |
|Fri |Lower B |Deadlift, front squat, walking lunge, leg extension, calf raise |
|Sat / Sun |Rest |- |

Upper A and Upper B are not identical - vary the main lift (flat vs incline, barbell vs pull-up emphasis) so both days together cover the muscle from more than one angle. Same idea on the lower days: one squat-led, one deadlift-led.

## Upper lower on three or six days

The split flexes if four days does not fit:

|Days |How to run it |
|---|---|---|
|3 |Alternate U / L / U one week, L / U / L the next - each muscle averages ~1.5x per week |
|4 |The standard two upper, two lower (best fit) |
|6 |Three upper, three lower - high frequency, closer to a [PPL](https://setkord.com/blog/push-pull-legs) workload |

Four is the sweet spot. Three works but drops frequency slightly; six is doable but starts competing with PPL, which is arguably built for that volume.

## Sets, reps, and volume

Nothing exotic: 5 to 8 reps on the heavy compounds, 8 to 15 on accessories. Because each muscle is trained twice a week, you split its weekly sets across two sessions - roughly 5 to 10 hard sets per muscle per day, landing near **10 to 20 hard sets per week**. That is the productive range covered in [training volume for muscle growth](https://setkord.com/blog/training-volume-for-muscle-growth) and [how many sets per week to build muscle](https://setkord.com/blog/how-many-sets-per-week-to-build-muscle).

Splitting volume across two days is one of the quiet advantages here: it is easier to do ten quality sets as two blocks of five than one gruelling block of ten.

## Who the upper lower split is for (and who it isn't)

**Upper/lower is a great fit if you:** can train three or four days, want each muscle hit twice a week, and want balanced progress in both size and strength without a six-day schedule.

**Look elsewhere if you:** can genuinely train six days and want the higher volume of [push pull legs](https://setkord.com/blog/push-pull-legs), can only train two to three days (a [full-body routine](https://setkord.com/blog/full-body-workout-routine) will hold frequency better), or are a raw beginner who would progress faster on a simple [5x5](https://setkord.com/blog/5x5-workout) first.

Not sure? Start from [how to build a workout routine](https://setkord.com/blog/how-to-build-a-workout-routine) and let your available days choose for you - four days points straight here.

## How to run upper/lower in Setkord

Four alternating sessions are easy to muddle from memory. Setkord is built for exactly this:


- **Save Upper A, Lower A, Upper B, and Lower B as routines** (or start from the built-in program library) and open the right one in a tap.
- **Your last weight and reps pre-fill** on every set, so [progressive overload](https://setkord.com/blog/progressive-overload) is obvious, not guesswork.
- **Personal records and your [estimated 1RM](https://setkord.com/blog/estimated-1rm-train-off-your-numbers) are tracked automatically.**
- It **works fully offline** and the core is **free forever**.

You run the split; Setkord keeps the score.

## FAQ

**Is the upper lower split good for building muscle?** Yes, it is one of the best. Training each muscle twice a week at moderate volume is a proven setup for hypertrophy, and the four-day schedule is realistic for most people to actually complete.

**How many days a week is an upper lower split?** Most commonly four - two upper, two lower. It also runs on three days (alternating) or six days (three of each), but four is the sweet spot for frequency and recovery.

**Upper lower or push pull legs - which is better?** Upper/lower is better if you can train three or four days; [PPL](https://setkord.com/blog/push-pull-legs) is better if you can train five or six and want more volume. Neither is superior in a vacuum - the right one is the one that matches your days.

**Should upper A and upper B be the same workout?** No. Vary the lead lifts and angles between them - one bench-led, one press- or pull-up-led - so across the week you cover each muscle from more than one angle instead of repeating the same session twice.

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/blog/upper-lower-split
