[Back to blog](https://setkord.com/blog)

# How Many Sets Per Week to Build Muscle? What the Research Says

26 August 2026 · Mark Stent

- training
- hypertrophy
- volume



Ask ten lifters how many sets you need to build muscle and you will get ten answers, most of them some version of "a few". It is the single most important training variable for growth, and almost nobody can tell you their real number. The research can, and it lands on something more useful than "a few".

Here is what the studies found, a target range you can actually use, and the part most people get wrong: what counts as a set in the first place.

## Volume is the main driver of growth

"Volume" here means the number of hard working sets you do for a muscle over a week. It is the variable most tightly linked to how much muscle you build.

The clearest evidence is a 2017 meta-analysis that pooled 15 studies. It found a graded dose-response relationship: as weekly sets went up, so did muscle growth, and groups doing ten or more sets per muscle per week grew significantly more than those doing fewer [1]. A controlled 2019 trial backed this up directly, assigning trained men to one, three, or five sets per exercise. Muscle growth followed the dose: the five-set group gained the most, the three-set group next, the one-set group least [2].

The short version: within reason, more hard sets means more muscle.

_Image: volume_



## So what is the target?

More is better, but not infinitely, and this is where the range comes from.

A 2022 systematic review concluded that **12 to 20 hard sets per muscle per week** is a sensible target for trained lifters chasing growth [3]. The most comprehensive analysis to date, a 2024 meta-regression of 67 studies and over 2,000 subjects, agrees that gains keep rising with volume but with clear diminishing returns: each extra set adds a little less than the one before [4].

Put together, a practical map looks like this.

|Where you are |Hard sets per muscle per week |Notes |
|---|---|---|
|Beginner (first year-ish) |6-10 |You grow on surprisingly little; don't rush to pile on volume |
|Intermediate |10-15 |The productive middle for most people, most of the time |
|Advanced / chasing a lagging muscle |15-20+ |Upper end, added gradually, watching recovery |

Start at the lower end of your row, train it hard for a few weeks, and add sets only when progress stalls. Volume is something you earn your way up to, not something you open with.

## What actually counts as a set

This is the part that quietly breaks people's math.

A "set" that counts toward growth is a **working set taken close to failure** - the last few reps genuinely hard. Three things do not count, even though people count them:


- **Warm-up sets.** Necessary, but they are practice, not stimulus. They should not go in the tally.
- **Half-effort sets** left five or six reps short of failure. Easy sets grow little.
- **Indirect work you are already counting elsewhere.** Your chest sets on a bench press already tax your triceps; you do not need to add all of that again to the triceps total, but some of it carries over.

So "I did four exercises" is not the same as "I did sixteen hard sets for my back". Count the working sets, per muscle, over the whole week - not per session, and not counting the warm-ups.

## Frequency: how to fit the sets in

If your target is fifteen sets for your back, you do not have to do them in one brutal session.

The research is reassuring here: once weekly volume is equal, how you split it across the week has little effect on growth [4]. Fifteen sets as one session or as three sessions of five grows about the same muscle.

That makes frequency a practical lever, not a magic one. Spreading a muscle's volume over two or three sessions usually means fresher, higher-quality sets and less soreness - so most people find it easier to hit and beat their targets that way, not because the split itself is superior.

## Where tracking comes in

All of this rests on one assumption: that you actually know your weekly set count per muscle. Almost nobody does, because it is genuinely annoying to add up across sessions in your head.

This is exactly the kind of thing Setkord is built to remove. It tracks your training volume and shows how it is distributed across muscle groups, so you can see at a glance whether your back is really getting the fifteen sets you think it is - or whether it has quietly been getting eight while your chest gets twenty. Warm-up sets are flagged and left out of the numbers, so your volume reflects real working sets, not padding.

That turns this article from a nice idea into something you can steer by: spot the starved muscle, add a couple of sets, and watch the balance even out.

## Wrapping up

Muscle is built by hard sets, counted per muscle, across the whole week. Aim for ten to twenty depending on your experience, keep the last reps genuinely hard, leave the warm-ups out of the count, and split the work across the week however you will actually recover from. Then measure it, because the target only works if you know your real number.

See where your volume is really going with [Setkord](https://setkord.com/).

## References


- Schoenfeld BJ, Ogborn D, Krieger JW. Dose-response relationship between weekly resistance training volume and increases in muscle mass: A systematic review and meta-analysis. Journal of Sports Sciences. 2017;35(11):1073-1082. [Link](https://pubmed.ncbi.nlm.nih.gov/27433992/)
- Schoenfeld BJ, Contreras B, Krieger J, et al. Resistance Training Volume Enhances Muscle Hypertrophy but Not Strength in Trained Men. Medicine & Science in Sports & Exercise. 2019;51(1):94-103. [Link](https://academicworks.cuny.edu/le_pubs/274/)
- Baz-Valle E, Balsalobre-Fernández C, Alix-Fages C, Santos-Concejero J. A Systematic Review of the Effects of Different Resistance Training Volumes on Muscle Hypertrophy. Journal of Human Kinetics. 2022;81:199-210. [Link](https://pmc.ncbi.nlm.nih.gov/articles/PMC8884877/)
- Pelland JC, Remmert JF, Robinson ZP, Hinson SR, Zourdos MC. The Resistance Training Dose Response: Meta-Regressions Exploring the Effects of Weekly Volume and Frequency on Muscle Hypertrophy and Strength Gains. 2024. [Link](https://pubmed.ncbi.nlm.nih.gov/41343037/)

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/blog/how-many-sets-per-week-to-build-muscle
