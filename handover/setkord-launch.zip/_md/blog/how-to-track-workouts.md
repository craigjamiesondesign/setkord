[Back to blog](https://setkord.com/blog)

# How to Track Your Workouts: The Complete Guide for Lifters

2 September 2026 · Mark Stent

- tracking
- progress



To track your workouts, record four things on every working set: the exercise, the weight, the reps, and how hard the set felt. Do that consistently and you have the one input that drives nearly all strength and muscle gain - a reliable record of what you did last time, so you know what to beat this time. Everything else in this guide is detail on top of those four numbers.

I have tracked every workout I have done for more than thirty years, first in notebooks and now on a phone. The habit is more responsible for my progress than any single program I have run. This is how to do it properly.

## Why tracking your workouts matters

[Progressive overload](https://setkord.com/blog/progressive-overload) - doing a bit more over time - is the mechanism behind almost all strength and size gains, and it runs on a reference number. "A bit more than last time" is not a number. Your memory of last Tuesday's third set is worse than you think, especially at rep eight when you are mostly concentrating on not dropping the bar.

A record fixes three problems at once. It tells you exactly what to beat, it makes stalls visible weeks before the mirror shows them, and it banks confidence for the days you feel weak and can't be bothered. The greatest lifters and athletes in history kept meticulous logs for exactly these reasons, which I wrote about in [Beat the Logbook](https://setkord.com/blog/beat-the-logbook).

## What to record on every set

Between decades of my own logs and the training journals of people far stronger than me, the list converges on this:

|Field |Why it matters |
|---|---|---|
|Exercise |The movement, including variation (incline vs flat, high-bar vs low-bar). |
|Weight |The actual load, not a rounded-up version of it. |
|Reps |Per set, not a total. Three sets of 8, 7, 6 is different from three sets of 7. |
|Effort (RPE or RIR) |How hard the set was. An easy 8 and a grinding 8 are not the same 8. |
|Warm-up flag |Warm-up sets should not count toward your working volume. |

If you record nothing else, record the first three. Effort is the field most people skip and the one that tells you next week whether to add load or repeat. More on that in [RPE vs RIR](https://setkord.com/blog/rpe-vs-rir).

## How to structure a workout log

The simplest workable structure is one entry per set, grouped under the exercise, grouped under the session date. That is all a good log is: a stack of dated sessions you can read backwards.

Two rules make it useful rather than just tidy:


- **Log it in the gym, not from memory afterwards.** The number you write between sets is accurate. The number you reconstruct on the sofa that night is a guess.
- **Read the last entry before your first working set.** This is the habit that turns a log from a diary into a tool. You walk up to the bar already knowing the weight and reps you have to beat.

## What to do with the numbers

A log you never read back is just a diary. The point is to act on it.


- **Compare like with like.** Same exercise, same rep range, week over week. If the weight or reps went up, you are progressing.
- **Watch for stalls.** Three or four sessions of the same lift stuck at the same numbers is a stall you can spot on a Tuesday, not something you work out in June when the mirror stops changing.
- **Track [training volume](https://setkord.com/blog/how-to-track-training-volume)** - sets and total load per muscle - if you are training for size, because [volume is the main lever for muscle growth](https://setkord.com/blog/training-volume-for-muscle-growth).
- **Track [strength progress](https://setkord.com/blog/how-to-track-lifting-progress)** with estimated 1RM if you are training to get strong, so you can see the trend under the day-to-day noise.

## Notebook, spreadsheet, or app?

All three work. They differ in friction.

A notebook is honest and reliable and never runs out of battery, but it does no arithmetic and shows you no trends without effort. A spreadsheet charts and totals, but building it and entering data by hand is a chore most people quit within a month. A purpose-built app does the pre-fill, the maths and the charts for you, which is the difference between a habit you keep and one you abandon.

I go into the full trade-off in [Beat the Logbook](https://setkord.com/blog/beat-the-logbook). The best tracker is the one you will still be using in six months, so pick for friction, not features.

## How Setkord tracks this for you

I built Setkord because after thirty years of logging I knew exactly which parts of tracking people quit over, and it is always the friction. So Setkord removes it:


- **Last weight and reps pre-fill** on every set, so you always know the number to beat without flicking back through pages.
- **Personal records are detected automatically**, and your [estimated 1RM](https://setkord.com/blog/estimated-1rm-train-off-your-numbers) is charted so you can see strength climb and spot a stall coming.
- **Effort logging is optional** (a simple 1-5 scale), there when you want the extra signal, out of the way when you don't.
- **Volume and muscle-balance stats** show where your work is actually going, and Insights trends (Pro) surface the patterns over months.
- **Body measurements** sit alongside the lifts, so you can line up what you did against what your body did.
- **Import from Strong or Hevy** brings your history with you, and it all **works fully offline** - the gym basement with no signal is exactly where you need it.

The core is **free forever**. You focus on adding weight; Setkord keeps the score.

## FAQ

**What is the most important thing to track in a workout?** Weight and reps per set. If you only ever record those two numbers for each working set, you have enough to apply progressive overload, which is the thing that actually drives progress.

**Should I track every set or just working sets?** Log both, but flag warm-ups so they don't count toward your working volume. Your progress is driven by your hard sets, so they are the ones that matter when you read the log back.

**How often should I review my workout log?** Read your last entry for a lift before every session so you know what to beat, and scan the trend every few weeks to catch stalls and check your volume is where you want it.

**Do I need an app, or is a notebook enough?** A notebook is genuinely enough to apply progressive overload. An app removes the friction - pre-filled numbers, automatic PRs, charts - which is mostly about whether you stick with the habit. See [Beat the Logbook](https://setkord.com/blog/beat-the-logbook).

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/blog/how-to-track-workouts
