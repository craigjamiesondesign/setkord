Free on iPhone

# Log every lift in two taps.Even with no signal.

Your last weight and reps are already filled in, the rest timer starts itself and new PRs show up the moment you hit them, all on your iPhone with or without a connection. [Download free](https://apps.apple.com/app/id6799150529)

Free to download. iPhone, iOS 17 or later.

_Image: Logging Bulgarian split squats in Setkord: last session's 28 kg × 8 pre-filled, two sets ticked off and a gold Log set button_



- Last numbers, pre-filled
- Rest timer starts itself
- PRs caught as you log
- Works offline

- Last numbers, pre-filled
- Rest timer starts itself
- PRs caught as you log
- Works offline



## Built for the seconds between sets

Two taps and the set is logged, with your last session's numbers already in place and the rest timer counting down. Warm-up sets, a plate calculator and per-set notes are there when you want them and out of the way when you don't.

- Weight x reps, bodyweight or timed sets
- Warm-ups never inflate your volume or steal a PR
- Supersets and giant sets stay as fast as a straight set

Bulgarian Split Squat

Last · 28 kg × 8 1:30

- 128 kg × 8last · 28 kg × 9PR
- 228 kg × 9last · 28 kg × 8PR
- 330 kg × 9last · 28 kg × 9PR KG28REPS9

Keep scrolling to log a set, or try it yourself.

## No signal? Keep lifting.

Setkord is local-first, so every set saves on your phone instantly, even in a basement gym with no reception. It all syncs the moment you're back online, with no spinners and no lost sets.

Basement gymNo signal

- Deadlift140 kg × 5Saved on iPhone
- Deadlift140 kg × 5Saved on iPhone
- Barbell Row70 kg × 8Saved on iPhone

_Image: Setkord's Progress screen with weekly volume, a trend line and muscle balance_

## Watch yourself get stronger

Every set feeds your progress charts, estimated 1RMs and training history automatically. Beat a best and the app celebrates it on the spot, so you see the trend, not just today.

Bulgarian Split Squat · estimated 1RM

30.0kgNew personal record28 kg × 9 · Bulgarian Split Squat

- Estimated 1RM for every lift
- Personal records detected as you log
- Weekly volume, streaks and muscle balance at a glance

## Your routines, ready in a tap

Build routines with target sets, reps and supersets, group them into programs and reorder exercises with a drag. Or start from a curated library of 36 multi-day programs, from Starting Strength and 5/3/1 to push, pull, legs.

- Starting Strength
- 5/3/1
- Push / Pull / Legs
- Upper / Lower
- Full Body 3x/week
- Barbell Strength

_Image: Setkord's Routines screen with your own routines and built-in programs_

_Image: Setkord's History calendar showing the days you trained_

## Built different, on purpose

Most lifting apps bury logging under menus and paywalls. Setkord puts the set first.[Explore all features](https://setkord.com/features)

### Log in two taps

Your last weight and reps are pre-filled. No menus, no fiddling between sets.

### Rest timer, PRs and 1RMs, automatic

The clock starts itself, and every set is checked against your history for personal records and estimated 1RMs.

### Accessible by design

Dynamic Type, VoiceOver and high-contrast mode are built in from day one, not added later.

### Free to start

No paywall before you've logged your first set. Upgrade to Pro only if you want more.

Your data

- Import from StrongCSV
- Import from HevyCSV
- Export everythingCSV

## Start on your real numbers

Import your history from Strong or Hevy with a CSV, so you don't start from a blank slate. Export everything to CSV any time, because your data is yours.

New

## On your Home Screen, Lock Screen and Siri

Glance at your Lock Screen or Dynamic Island for a live rest countdown without unlocking, keep your streak on the Home Screen, and start training by saying "Hey Siri, start my Setkord workout."

- Streak and weekly-volume widget
- Live rest timer on the Lock Screen and Dynamic Island
- Start a workout with Siri, a widget or a tap
- Finished workouts save to Apple Health (optional)

Works offline. Included free.

_Image: Lock Screen with a live Setkord rest timer counting down_

_Image: Home Screen with the Setkord streak widget_

## Built by a lifter who tracks everything

Setkord is made by Mark Stent, who held the WABBA South African heavyweight bodybuilding title and is a data scientist who has tracked his training for over thirty years. It's the log he built for himself and uses every session.[Read Mark's story](https://setkord.com/about)



## Questions, answered [Visit the help centre](https://setkord.com/help)

- 01

### How much does it cost?

Free to download and use, and you'll always be able to log workouts. Setkord Pro (monthly or annual) adds unlimited routines, your full training history and advanced insights.
- 02

### What does it run on?

iPhone, on the App Store now (iOS 17 or later).
- 03

### Does it work without signal?

Yes. Every set saves on your phone with no connection and syncs when you're back online.
- 04

### Can I bring my old workouts?

Yes. Import your history from Strong or Hevy with a CSV, and export your data to CSV any time.
- 05

### Is my data private?

Yes. We only collect anonymous analytics, and you can export or delete your data anytime. See our [privacy policy](https://setkord.com/privacy) for details.
- 06

### Is there an Android version?

Not yet. If you'd use it, tell us through the [contact page](https://setkord.com/contact).

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/
