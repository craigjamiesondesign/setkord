[Back to blog](https://setkord.com/blog)

# Push Pull Legs Split (PPL): The Complete Guide and Weekly Plan

2 September 2026 · Mark Stent

- programs
- training



The push pull legs split (PPL) groups your training into three sessions: push (chest, shoulders, triceps), pull (back, biceps, rear delts), and legs (quads, hamstrings, glutes, calves). You run those three days either once through for a three-day week, or twice through for a six-day week. It is popular because the grouping is logical - muscles that work together get trained together - and because it scales cleanly from three days to six.

## What is the push pull legs split?

PPL sorts every exercise by the movement pattern it uses:


- **Push:** everything that presses away from you - bench press, overhead press, dips, lateral raises, triceps.
- **Pull:** everything that pulls toward you - rows, pull-ups, lat pulldowns, face pulls, biceps.
- **Legs:** everything below the waist - squats, deadlifts, leg press, hamstring curls, calves.

The logic is that the muscles in each group already assist each other, so training them in the same session is efficient and you are not accidentally hitting triceps hard the day before a heavy bench.

## The push pull legs weekly plan

Here is a full six-day PPL week. Compounds lead each session, accessories follow:

|Day |Focus |Example exercises |
|---|---|---|
|Mon |Push |Bench press, overhead press, incline dumbbell press, lateral raise, triceps pushdown |
|Tue |Pull |Deadlift, barbell row, pull-up, face pull, barbell curl |
|Wed |Legs |Squat, Romanian deadlift, leg press, leg curl, calf raise |
|Thu |Push |Overhead press, incline bench, dip, lateral raise, overhead triceps extension |
|Fri |Pull |Barbell row, lat pulldown, chest-supported row, rear delt fly, hammer curl |
|Sat |Legs |Front squat, hip thrust, walking lunge, leg extension, calf raise |
|Sun |Rest |- |

Running it six days hits every muscle group **twice a week**, which is a big part of why PPL works so well for size once you can recover from that volume.

## Push pull legs on three days a week

You do not need six days to run PPL. On three days, you simply do one push, one pull, one legs and rest the other days:

|Day |Focus |
|---|---|---|
|Mon |Push |
|Wed |Pull |
|Fri |Legs |

The trade-off is honest: each muscle now gets hit **once a week** instead of twice. That is fine for a beginner or anyone time-limited, but if you can only train three days, an [upper/lower split](https://setkord.com/blog/upper-lower-split) or a [full-body routine](https://setkord.com/blog/full-body-workout-routine) usually gives each muscle more frequency and is the better call. PPL earns its keep at five or six days.

## Sets, reps, and volume on PPL

The rep ranges are nothing exotic - 5 to 8 on the heavy compounds, 8 to 15 on accessories. What matters is the weekly total. Six-day PPL naturally lands each muscle around **12 to 20 hard sets per week**, which sits right in the productive range covered in [training volume for muscle growth](https://setkord.com/blog/training-volume-for-muscle-growth) and [how many sets per week to build muscle](https://setkord.com/blog/how-many-sets-per-week-to-build-muscle).

Do not add sets just because the split has room. Add them because you are recovering from what you already do and still progressing.

## Who push pull legs is for (and who it isn't)

**PPL is a great fit if you:** can train five or six days a week, want high frequency and volume for size, are past the pure-beginner stage, and like a clear, repeatable structure.

**Look elsewhere if you:** can only train three or four days (an [upper/lower split](https://setkord.com/blog/upper-lower-split) or [full body](https://setkord.com/blog/full-body-workout-routine) will give you more frequency per muscle), are a brand-new beginner who would progress faster on a simple [5x5](https://setkord.com/blog/5x5-workout), or cannot reliably recover from six sessions a week - in which case the extra days are just fatigue, not gains.

If you are still deciding, start from [how to build a workout routine](https://setkord.com/blog/how-to-build-a-workout-routine) and let your available days pick the split.

## How to run PPL in Setkord

Six sessions with different exercises is a lot to keep straight from memory. Setkord is built for exactly this:


- **Save Push, Pull, and Legs as three routines** (or start from the built-in program library) and open the right one in a tap.
- **Your last weight and reps pre-fill** on every set, so you always know the next jump - the core of [progressive overload](https://setkord.com/blog/progressive-overload).
- **Personal records and your [estimated 1RM](https://setkord.com/blog/estimated-1rm-train-off-your-numbers) are tracked automatically** across all six sessions.
- It **works fully offline** and the core is **free forever**.

You run the split; Setkord keeps the score.

## FAQ

**Is push pull legs good for building muscle?** Yes. Run six days, PPL trains every muscle twice a week at high volume, which is close to ideal for hypertrophy - provided you can recover from six sessions. On three days it is fine but no longer its best self.

**How many days a week is push pull legs?** Either three (one round) or six (two rounds). Six is where PPL shines because it doubles weekly frequency. If you only have three or four days, an [upper/lower split](https://setkord.com/blog/upper-lower-split) usually fits better.

**Can beginners do push pull legs?** They can, but most beginners progress faster on a simpler high-frequency plan like [full body](https://setkord.com/blog/full-body-workout-routine) or [5x5](https://setkord.com/blog/5x5-workout). PPL makes more sense once you have a training base and can commit to five or six days.

**What order should I do push, pull, and legs?** Any order works, but push then pull then legs is common so a heavy leg day is not sitting right before you press. Just keep at least a day between two sessions that hammer the same muscles.

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/blog/push-pull-legs
