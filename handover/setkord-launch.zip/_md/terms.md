# Terms of service

Last updated: September 2026

- [Acceptance of these terms](#acceptance-of-these-terms)
- [Eligibility](#eligibility)
- [Accounts & security](#accounts-and-security)
- [Acceptable use](#acceptable-use)
- [Subscriptions, billing & cancellation](#subscriptions-billing-and-cancellation)
- [Intellectual property](#intellectual-property)
- [Your content & shared routines](#your-content-and-shared-routines)
- [Disclaimers](#disclaimers)
- [Limitation of liability](#limitation-of-liability)
- [Termination](#termination)
- [Changes to the service](#changes-to-the-service)
- [Apple App Store](#apple-app-store)
- [Governing law](#governing-law)
- [Changes to these terms](#changes-to-these-terms)
- [Contact](#contact)

## Acceptance of these terms

Setkord is operated by Mashwork LTD, a company registered in England and Wales with its registered office at 3rd Floor, 86-90 Paul Street, London, England, EC2A 4NE, United Kingdom (“Setkord”, “we”, “us”, or “our”). By creating a Setkord account or using the app, you agree to these Terms of Service. If you do not agree, please do not use Setkord. If you are using Setkord on behalf of an organisation, you confirm you are authorised to accept these terms on its behalf.

## Eligibility

You must be at least 13 years old (or 16, if you are in the European Economic Area or the United Kingdom) to use Setkord, and you must be able to form a binding contract under the laws that apply to you. By using Setkord, you confirm that you meet this requirement.

## Accounts & security

- You are responsible for keeping your login credentials secure and for any activity that happens under your account.
- You must provide accurate account information and keep your email address current, so we can reach you about password resets and important service notices.
- You can delete your account at any time from the Profile screen. Deletion is permanent and removes your training data, routines, and personal records. There is no recovery after deletion.

## Acceptable use

You agree not to:

- use Setkord for any unlawful purpose or in violation of any applicable law;
- access or attempt to access another user’s data, or probe, disrupt, or circumvent the security of the service;
- reverse engineer, scrape, or resell the service except where the law expressly permits it; or
- upload content that is unlawful, abusive, or infringes someone else’s rights.

## Subscriptions, billing & cancellation

Setkord offers a free tier and an optional paid subscription, **Setkord Pro**, sold as an auto-renewing in-app purchase through the Apple App Store. Where a plan is paid:

- the subscription title, length of each billing period, and price (including price per period) are shown in the app before you purchase;
- the subscription renews automatically, and your Apple account is charged within 24 hours before the end of the current period, unless you turn off auto-renew at least 24 hours before it ends;
- if a free trial is offered, any unused portion is forfeited when you purchase a subscription to that content;
- payments are processed by Apple through the App Store (in-app purchase); we never receive or store your card details;
- you can manage your subscription, and turn off auto-renew, at any time in your Apple ID / App Store settings; access continues until the end of the then-current billing period; and
- except where required by law, fees already paid are non-refundable; refund requests are handled by Apple under its policies.

Your use of the app is also subject to Apple’s standard Licensed Application End User License Agreement (EULA), available at [apple.com/legal/internet-services/itunes/dev/stdeula](https://www.apple.com/legal/internet-services/itunes/dev/stdeula/).

## Intellectual property

Setkord, its software, design, and branding are owned by us or our licensors and are protected by intellectual property laws. We grant you a personal, non-exclusive, non-transferable licence to use the app for its intended purpose. The training data you enter remains yours; see our [Privacy Policy](https://setkord.com/privacy) for how we handle it.

## Your content & shared routines

You keep ownership of the routines and content you create. When you choose to **share** a routine (for example via a share link), you grant Setkord a worldwide, non-exclusive, royalty-free licence to host, store, reproduce, publicly display, and transmit that content for the purpose of operating the sharing feature, and you grant other users a licence to view, import, and use a copy of the shared routine. A copy another user imports is their own and is independent of your original.

You are responsible for the content you upload or share, and you confirm you have the rights to do so. You agree not to share content that is unlawful, infringing, or otherwise breaches these terms.

We may remove or disable access to shared content at our discretion - including content we reasonably believe is unlawful, infringing, or abusive - and we may terminate repeat infringers. If you believe content on Setkord infringes your rights, contact us at [hello@setkord.com](mailto:hello@setkord.com) with details and we will review it.

To the extent permitted by law, you agree to indemnify and hold harmless Mashwork LTD from any third-party claim arising out of content you upload or share, or your breach of these terms.

## Disclaimers

Setkord is provided “as is” and “as available”, without warranties of any kind, whether express or implied, including warranties of merchantability, fitness for a particular purpose, and non-infringement.

Setkord is a logging and analytics tool, not a medical or fitness professional. Nothing in the app is medical, health, or professional fitness advice, and it is not a substitute for guidance from a qualified professional. Consult a doctor or qualified trainer before starting or changing any exercise programme, especially if you have a medical condition or an injury. You train at your own risk and are responsible for your own safety.

## Limitation of liability

To the fullest extent permitted by law, Setkord and its operators will not be liable for any indirect, incidental, special, consequential, or punitive damages, or for any loss of data, arising out of your use of the service. Where liability cannot be excluded, it is limited to the amount you paid us for the service in the twelve months before the claim.

## Termination

We may suspend or terminate your access to Setkord if you breach these terms or misuse the service. You may stop using Setkord, and delete your account, at any time. Provisions that by their nature should survive termination - including intellectual property, disclaimers, and limitation of liability - will survive.

## Changes to the service

Setkord is under active development. We may add, change, or discontinue features at any time. Because Setkord is local-first, older app versions may keep running for a time after a change; we aim to keep them working and to give notice of significant changes where practical.

## Apple App Store

These terms are between you and Mashwork LTD only, not with Apple. Apple is not responsible for the app or its content and has no obligation to furnish any maintenance or support for it, nor to address any claims relating to it. Apple and its subsidiaries are third-party beneficiaries of these terms and may enforce them against you as a user.

## Governing law

These terms are governed by the laws of England and Wales, without regard to its conflict-of-laws principles. Any dispute arising from these terms or your use of Setkord is subject to the exclusive jurisdiction of the courts of England and Wales, except where local consumer-protection law grants you the right to bring proceedings in your own country of residence.

## Changes to these terms

We may update these terms from time to time. When we do, we will update the “Last updated” date above, and for material changes we will notify you by email or through the app. Continuing to use Setkord after a change takes effect means you accept the revised terms.

## Contact

Questions about these terms: [hello@setkord.com](mailto:hello@setkord.com). We aim to respond within a reasonable time.

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/terms
