[Back to blog](https://setkord.com/blog)

# How Long Should You Rest Between Sets? A Research-Backed Cheat Sheet

26 August 2026 · Mark Stent

- training
- hypertrophy
- strength



The rest between sets is the one training variable almost nobody tracks, and it quietly decides how much weight you can move on the next set. Rest too little and your working weight collapses set to set. Rest by feel and it drifts from forty seconds to four minutes depending on who texted you.

For years the standard advice was simple: short rests for muscle, long rests for strength. It turns out that advice was built on a mechanism that does not hold up. Here is what the research actually says, and a cheat sheet you can use on your next session.

## The myth: short rest builds more muscle

The "short rest for hypertrophy" idea came from a real observation. Resting only 30 to 60 seconds produces a bigger acute spike in growth hormone and testosterone than long rests do. The assumption was that those hormone spikes drove muscle growth, so more spike meant more muscle.

That assumption has since been overturned. The acute post-workout hormone surge does not meaningfully drive long-term hypertrophy, and rushing your rest carries a real cost: it slashes the reps and load you can handle on later sets. Since training volume, load lifted for reps across all your working sets, is a primary driver of both size and strength, cutting your rest short can quietly cut your results.

The clearest test came from Brad Schoenfeld's lab in 2016. Resistance-trained men followed the same program with volume held equal, one group resting one minute between sets, the other resting three minutes. The three-minute group gained more strength on the bench press and squat, and more muscle thickness in the arms and quads [1]. More rest, better results, same amount of work.

_Image: timer_



## What the reviews conclude

Zoom out to the systematic reviews and the picture is consistent.

For maximal strength, longer is better. A 2018 systematic review of chronic training studies found that rest intervals of roughly two minutes or more generally produced greater strength gains than shorter ones [2]. The classic 2009 review in Sports Medicine reached the same place, recommending three to five minutes between sets when the goal is maximal strength [3]. The American College of Sports Medicine's position stand recommends two to three minutes for heavy multi-joint lifts, and one to two minutes for smaller assistance exercises [4].

For muscle growth, rest is less of a lever than people think, as long as you protect your volume. A 2017 review found that both short and long rests can work for hypertrophy, but longer intervals may have the edge for people who already have training experience [5]. The takeaway is not "rest forever", it is "rest long enough that your next set is not compromised".

## The cheat sheet

Use these as starting points, then adjust to the readiness cues in the next section.

|Your goal |Rest between sets |Why |
|---|---|---|
|Max strength, heavy compounds (1-5 reps) |3-5 min |Full energy and nervous-system recovery so you can hit heavy loads |
|Hypertrophy, compound lifts (6-12 reps) |2-3 min |Preserves reps and load across sets, which is what drives growth |
|Hypertrophy, isolation / small muscles |60-90 sec |Small muscles recover fast and cause little systemic fatigue |
|Muscular endurance / circuits |30-60 sec |Deliberately trains fatigue resistance |
|Power / explosive work (cleans, jumps) |2-5 min |Every rep should be crisp, never fatigued |

## Rest by readiness, not just the clock

The numbers above are a floor, not a law. The real question each set is: am I recovered enough to hit my target reps with good form?

Three cues tell you the answer without a stopwatch. Your breathing has settled back toward normal. You can speak a full sentence without gasping. And you genuinely believe you can match, or beat, the reps you just did.

If your reps fall off a cliff from one set to the next, that is the signal to rest longer, not to grind through with a lighter effective load. On the flip side, resting five minutes between sets of biceps curls just makes your session long without making it better.

## Where tracking comes in

Rest only helps if it is consistent, and consistent rest is exactly the kind of thing that slips when you are training hard. This is why Setkord starts a rest timer automatically the moment you log a set, so the clock is running whether or not you remember to start it. The countdown also lives on your Lock Screen and Dynamic Island, so you are not stuck staring at the app between sets waiting for a number to hit zero.

Keeping your rest steady does something quieter too. When rest is consistent, your set-to-set performance becomes a clean signal, and the strength and estimated-1RM trends Setkord builds from your logs actually mean something, instead of being noise from a session where you happened to rest twice as long.

## Wrapping up

Forget "short for size, long for strength". Rest at least two to three minutes on your big compound lifts, drop to 60 to 90 seconds on isolation work, and let your breathing and rep quality fine-tune the rest. Then track it, so the number stays honest, and your progress data stays trustworthy.

Log every set, and let the timer run itself, with [Setkord](https://setkord.com/).

## References


- Schoenfeld BJ, Pope ZK, Benik FM, et al. Longer Interset Rest Periods Enhance Muscle Strength and Hypertrophy in Resistance-Trained Men. Journal of Strength and Conditioning Research. 2016;30(7):1805-1812. [Link](https://journals.lww.com/nsca-jscr/fulltext/2016/07000/longer_interset_rest_periods_enhance_muscle.3.aspx)
- Grgic J, Schoenfeld BJ, Skrepnik M, Davies TB, Mikulic P. Effects of Rest Interval Duration in Resistance Training on Measures of Muscular Strength: A Systematic Review. Sports Medicine. 2018;48(1):137-151. [Link](https://link.springer.com/article/10.1007/s40279-017-0788-x)
- de Salles BF, Simão R, Miranda F, et al. Rest Interval between Sets in Strength Training. Sports Medicine. 2009;39(9):765-777. [Link](https://pubmed.ncbi.nlm.nih.gov/19691365/)
- Ratamess NA, Alvar BA, Evetoch TK, et al. American College of Sports Medicine position stand. Progression models in resistance training for healthy adults. Medicine & Science in Sports & Exercise. 2009;41(3):687-708. [Link](https://pubmed.ncbi.nlm.nih.gov/19204579/)
- Grgic J, Lazinica B, Mikulic P, Krieger JW, Schoenfeld BJ. The effects of short versus long inter-set rest intervals in resistance training on measures of muscle hypertrophy: A systematic review. European Journal of Sport Science. 2017;17(8):983-993. [Link](https://onlinelibrary.wiley.com/doi/10.1080/17461391.2017.1340524)

## Log your first set today

Setkord is free on iPhone. Download it and you're logging in seconds.[Download free](https://apps.apple.com/app/id6799150529)

iPhone, iOS 17 or later.

---
Canonical: https://setkord.com/blog/how-long-to-rest-between-sets
